import { createHmac, randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import { JWT } from "google-auth-library";
import { mapSheetLeads, mapSheetSpend } from "./sheets-mapping";
import { loadAdmin, saveAdmin, loadTeam, saveTeam, type AdminCredentials, type TeamCredentials } from "./admin-store.server";
import { operationalLead } from "./operational-data";

const cookieName = "soares_session";
const attempts = { count: 0, resetAt: 0 };
const authConfigured = () =>
  Boolean(
    process.env["DASHBOARD_USER"] &&
    process.env["DASHBOARD_PASSWORD_HASH"] &&
    (process.env["DASHBOARD_SESSION_SECRET"]?.length ?? 0) >= 32,
  );
const sheetsConfigured = () =>
  Boolean(
    process.env["GOOGLE_SERVICE_ACCOUNT_EMAIL"] &&
    process.env["GOOGLE_PRIVATE_KEY"] &&
    process.env["GOOGLE_SHEET_ID"] &&
    process.env["GOOGLE_LEADS_RANGE"],
  );
const json = (body: unknown, status = 200, extra: Record<string, string> = {}) =>
  new Response(JSON.stringify(body), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "private, no-store",
      "x-content-type-options": "nosniff",
      ...extra,
    },
  });
function digest(text: string) {
  return createHmac("sha256", process.env["DASHBOARD_SESSION_SECRET"] ?? "")
    .update(text)
    .digest();
}
export function createSession(version = "initial", role: "admin" | "soares" = "admin", user = process.env["DASHBOARD_USER"]) {
  const payload = Buffer.from(
    JSON.stringify({
      exp: Date.now() + 8 * 60 * 60 * 1000,
      nonce: randomBytes(16).toString("hex"),
      user,
      role,
      version,
    }),
  ).toString("base64url");
  return payload + "." + digest(payload).toString("base64url");
}
export function validSession(request: Request, version = "initial", role: "admin" | "soares" = "admin", user = process.env["DASHBOARD_USER"]) {
  if (!authConfigured()) return false;
  const cookie = request.headers
    .get("cookie")
    ?.split(";")
    .map((c) => c.trim())
    .find((c) => c.startsWith(cookieName + "="))
    ?.slice(cookieName.length + 1);
  if (!cookie) return false;
  try {
    const [payload, signature, extra] = cookie.split(".");
    if (!payload || !signature || extra) return false;
    const expected = digest(payload),
      received = Buffer.from(signature, "base64url");
    const claims = JSON.parse(Buffer.from(payload, "base64url").toString());
    return (
      expected.length === received.length &&
      timingSafeEqual(expected, received) &&
      Number(claims.exp) > Date.now() &&
      claims.user === user &&
      claims.role === role && claims.version === version
    );
  } catch {
    return false;
  }
}
function cookieHeader(request: Request, value: string, age: number) {
  const secure = new URL(request.url).protocol === "https:";
  return `${cookieName}=${value}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${age}${secure ? "; Secure" : ""}`;
}
function sameOrigin(request: Request) {
  return request.headers.get("origin") === new URL(request.url).origin;
}
function passwordMatches(password: string, storedHash = process.env["DASHBOARD_PASSWORD_HASH"] ?? "") {
  const [scheme, salt, hash] = storedHash.split(":");
  if (scheme !== "scrypt" || !salt || !hash || password.length > 256) return false;
  const expected = Buffer.from(hash, "hex"),
    received = scryptSync(password, salt, 64);
  return expected.length === received.length && timingSafeEqual(expected, received);
}

async function sheetValues(client: JWT, range: string) {
  const id = process.env["GOOGLE_SHEET_ID"]!;
  const url = `https://sheets.googleapis.com/v4/spreadsheets/${encodeURIComponent(id)}/values/${encodeURIComponent(range)}?valueRenderOption=FORMATTED_VALUE`;
  const response = await client.request<{ values?: unknown[][] }>({
    url,
    method: "GET",
    timeout: 15000,
  });
  return response.data.values ?? [];
}

export async function handleDashboardApi(request: Request): Promise<Response | null> {
  const pathname = new URL(request.url).pathname;
  if (!pathname.startsWith("/api/dashboard")) return null;
  let snapshot;
  try { snapshot = await loadAdmin(); }
  catch { return json({ error: "Acesso temporariamente indisponível. Tente novamente." }, 503); }
  const credentials: AdminCredentials = snapshot.credentials;
  // Resolve the role on the server. No request/query/body value can grant access.
  let team;
  try { team = await loadTeam(); }
  catch { return json({ error: "Acesso temporariamente indisponível. Tente novamente." }, 503); }
  const adminSession = validSession(request, credentials.version);
  const teamSession = Boolean(team.credentials?.enabled && validSession(request, team.credentials.version, "soares", team.credentials.user));
  const role = adminSession ? "admin" : teamSession ? "soares" : null;
  const sessionUser = role === "admin" ? process.env["DASHBOARD_USER"] : role === "soares" ? team.credentials!.user : null;
  if (pathname === "/api/dashboard/session" && request.method === "GET") {
    return json({ configured: authConfigured(), authenticated: Boolean(role), role, ...(role ? { user: sessionUser } : {}) });
  }
  if (pathname === "/api/dashboard/login" && request.method === "POST") {
    if (!sameOrigin(request)) return json({ error: "Origem inválida." }, 403);
    if (!authConfigured())
      return json({ error: "O acesso ainda não foi configurado no servidor." }, 503);
    if (Date.now() > attempts.resetAt) {
      attempts.count = 0;
      attempts.resetAt = Date.now() + 15 * 60 * 1000;
    }
    if (attempts.count >= 5) return json({ error: "Muitas tentativas. Aguarde 15 minutos." }, 429);
    attempts.count++;
    let data: { user?: unknown; password?: unknown };
    try {
      data = await request.json();
    } catch {
      return json({ error: "Dados inválidos." }, 400);
    }
    const isAdmin = data.user === process.env["DASHBOARD_USER"];
    const isTeam = Boolean(team.credentials?.enabled && data.user === team.credentials.user && !isAdmin);
    const selected = isAdmin ? credentials : isTeam ? team.credentials! : credentials;
    const passwordOk = typeof data.password === "string" && passwordMatches(data.password, selected.passwordHash);
    if ((!isAdmin && !isTeam) || !passwordOk)
      return json({ error: "Usuário ou senha inválidos." }, 401);
    attempts.count = 0;
    return json({ ok: true }, 200, {
      "set-cookie": cookieHeader(request, createSession(selected.version, isAdmin ? "admin" : "soares", String(data.user)), 8 * 60 * 60),
    });
  }
  if (pathname === "/api/dashboard/logout" && request.method === "POST") {
    if (!sameOrigin(request)) return json({ error: "Origem inválida." }, 403);
    return json({ ok: true }, 200, { "set-cookie": cookieHeader(request, "", 0) });
  }
  if (pathname === "/api/dashboard/team") {
    if (!role) return json({ error: "Entre novamente." }, 401);
    if (role !== "admin") return json({ error: "Acesso exclusivo do administrador." }, 403);
    if (request.method === "GET") return json({ user: team.credentials?.user ?? "soares", enabled: team.credentials?.enabled ?? false });
    if (request.method !== "POST") return json({ error: "Método não permitido." }, 405);
    if (!sameOrigin(request)) return json({ error: "Origem inválida." }, 403);
    if (Date.now() > attempts.resetAt) { attempts.count = 0; attempts.resetAt = Date.now() + 15 * 60 * 1000; }
    if (attempts.count >= 5) return json({ error: "Muitas tentativas. Aguarde 15 minutos." }, 429);
    let data: { user?: unknown; password?: unknown; confirmation?: unknown; currentPassword?: unknown; enabled?: unknown };
    try { data = await request.json(); } catch { return json({ error: "Dados inválidos." }, 400); }
    attempts.count++;
    if (typeof data.currentPassword !== "string" || !passwordMatches(data.currentPassword, credentials.passwordHash))
      return json({ error: "Confirme a senha atual do administrador." }, 401);
    const user = typeof data.user === "string" ? data.user.trim() : "";
    if (!/^[a-zA-Z0-9._-]{3,64}$/.test(user) || user === process.env["DASHBOARD_USER"])
      return json({ error: "Use um login diferente do administrador, de 3 a 64 caracteres." }, 400);
    if (typeof data.enabled !== "boolean") return json({ error: "Estado inválido." }, 400);
    if (data.enabled && (typeof data.password !== "string" || data.password.length < 12 || data.password.length > 256 || data.password !== data.confirmation))
      return json({ error: "Defina e confirme uma senha de 12 a 256 caracteres." }, 400);
    if (data.enabled && typeof data.password === "string" && passwordMatches(data.password, credentials.passwordHash))
      return json({ error: "Use uma senha diferente da senha do administrador." }, 400);
    const salt = randomBytes(16).toString("hex");
    const updated: TeamCredentials = {
      user, enabled: data.enabled, version: randomBytes(24).toString("hex"),
      passwordHash: data.enabled ? "scrypt:" + salt + ":" + scryptSync(String(data.password), salt, 64).toString("hex") : team.credentials?.passwordHash ?? "",
    };
    try { await saveTeam(updated, team); }
    catch { return json({ error: "Não foi possível salvar o acesso da equipe. Tente novamente." }, 503); }
    attempts.count = 0;
    return json({ ok: true, user: updated.user, enabled: updated.enabled });
  }
  if (pathname === "/api/dashboard/password" && request.method === "POST") {
    if (!sameOrigin(request)) return json({ error: "Origem inválida." }, 403);
    if (!role) return json({ error: "Entre novamente para alterar a senha." }, 401);
    const ownCredentials = role === "admin" ? credentials : team.credentials!;
    if (Date.now() > attempts.resetAt) {
      attempts.count = 0;
      attempts.resetAt = Date.now() + 15 * 60 * 1000;
    }
    if (attempts.count >= 5) return json({ error: "Muitas tentativas. Aguarde 15 minutos." }, 429);
    let data: { currentPassword?: unknown; newPassword?: unknown; confirmation?: unknown };
    try { data = await request.json(); }
    catch { return json({ error: "Dados inválidos." }, 400); }
    attempts.count++;
    if (typeof data.currentPassword !== "string" || !passwordMatches(data.currentPassword, ownCredentials.passwordHash))
      return json({ error: "Senha atual incorreta." }, 401);
    if (typeof data.newPassword !== "string" || data.newPassword.length < 12 || data.newPassword.length > 256)
      return json({ error: "Use uma nova senha entre 12 e 256 caracteres." }, 400);
    if (data.newPassword !== data.confirmation) return json({ error: "A confirmação não corresponde à nova senha." }, 400);
    if (data.newPassword === data.currentPassword) return json({ error: "Escolha uma senha diferente da atual." }, 400);
    const salt = randomBytes(16).toString("hex");
    const updated: AdminCredentials = {
      passwordHash: "scrypt:" + salt + ":" + scryptSync(data.newPassword, salt, 64).toString("hex"),
      version: randomBytes(24).toString("hex"),
    };
    try {
      if (role === "admin") await saveAdmin(updated, snapshot);
      else await saveTeam({ ...team.credentials!, ...updated }, team);
    }
    catch { return json({ error: "Não foi possível salvar a nova senha. Ela não foi confirmada; tente novamente." }, 503); }
    attempts.count = 0;
    return json({ ok: true }, 200, { "set-cookie": cookieHeader(request, "", 0) });
  }
  if (pathname !== "/api/dashboard" || request.method !== "GET")
    return json({ error: "Rota não encontrada." }, 404);
  const authenticated = Boolean(role);
  const configured = authConfigured() && sheetsConfigured();
  const integration = {
    configured,
    authenticated,
    connected: false,
    updatedAt: null as string | null,
  };
  if (!configured || !authenticated) return json({ integration, leads: [], spend: [] });
  try {
    const client = new JWT({
      email: process.env["GOOGLE_SERVICE_ACCOUNT_EMAIL"]!,
      key: process.env["GOOGLE_PRIVATE_KEY"]!.replaceAll("\\n", "\n"),
      scopes: ["https://www.googleapis.com/auth/spreadsheets.readonly"],
    });
    const leads = mapSheetLeads(await sheetValues(client, process.env["GOOGLE_LEADS_RANGE"]!));
    const spendRange = process.env["GOOGLE_SPEND_RANGE"];
    const spend = role === "admin" && spendRange ? mapSheetSpend(await sheetValues(client, spendRange)) : [];
    return json({
      integration: { ...integration, connected: true, updatedAt: new Date().toISOString() },
      leads: role === "soares" ? leads.map(operationalLead) : leads,
      spend,
    });
  } catch {
    return json(
      {
        error:
          "Não foi possível ler a planilha. Confira as credenciais, os cabeçalhos e a permissão de leitura.",
      },
      502,
    );
  }
}
