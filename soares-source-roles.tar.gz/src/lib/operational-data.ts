import { leadStatuses, sanitizeLeads, type Lead } from "./dashboard-data";
import { dateKey } from "./dashboard-analytics";

// Explicit allow-list: adding a new field to Lead does not expose it to the team.
export function operationalLead(lead: Lead) {
  return {
    id: lead.id, entryDate: lead.entryDate, name: lead.name, phone: lead.phone,
    email: lead.email, financingType: lead.financingType, installmentValue: lead.installmentValue,
    status: lead.status, consultant: lead.consultant, notes: lead.notes,
    lastContact: lead.lastContact, nextReturn: lead.nextReturn,
  };
}

export function operationalSummary(input: Lead[], today: string) {
  const leads = sanitizeLeads(input);
  const previous = new Date(today + "T12:00:00Z");
  previous.setUTCDate(previous.getUTCDate() - 1);
  const yesterday = previous.toISOString().slice(0, 10);
  const unassigned = (name: string) => !name.trim() || name === "Sem atribuição" || name === "Sem responsável";
  const names = [...new Set(leads.map(l => unassigned(l.consultant) ? "Sem responsável" : l.consultant.trim()))];
  return {
    total: leads.length,
    today: leads.filter(l => dateKey(l.entryDate) === today).length,
    yesterday: leads.filter(l => dateKey(l.entryDate) === yesterday).length,
    unassigned: leads.filter(l => unassigned(l.consultant)).length,
    statuses: leadStatuses.map(status => ({ status, count: leads.filter(l => l.status === status).length })),
    consultants: names.sort((a,b) => a.localeCompare(b, "pt-BR")).map(name => {
      const own = leads.filter(l => (unassigned(l.consultant) ? "Sem responsável" : l.consultant.trim()) === name);
      const counts = Object.fromEntries(leadStatuses.map(status => [status, own.filter(l => l.status === status).length])) as Record<typeof leadStatuses[number], number>;
      return { name, leads: own.length, counts, conversion: own.length ? counts.Fechado / own.length : 0 };
    }),
  };
}
