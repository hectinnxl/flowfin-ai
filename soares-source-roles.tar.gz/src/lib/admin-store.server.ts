import { getStore } from "@netlify/blobs";

export type AdminCredentials = { passwordHash: string; version: string };
export type AdminSnapshot = { credentials: AdminCredentials; etag?: string | undefined };
export type TeamCredentials = AdminCredentials & { user: string; enabled: boolean };
export type TeamSnapshot = { credentials: TeamCredentials | null; etag?: string | undefined };

function store() {
  // Keep preview and production password state separate, but persistent across deploys.
  const context = process.env["CONTEXT"] ?? "production";
  return getStore({ name: `soares-admin-${context}`, consistency: "strong" });
}

export async function loadAdmin(): Promise<AdminSnapshot> {
  if (process.env["SOARES_NETLIFY_RUNTIME"] === "true") {
    const entry = await store().getWithMetadata("credentials", { type: "json" });
    if (entry) {
      const data = entry.data as AdminCredentials;
      if (typeof data.passwordHash !== "string" || typeof data.version !== "string") {
        throw new Error("Invalid credential record");
      }
      return { credentials: data, etag: entry.etag };
    }
  }
  return { credentials: { passwordHash: process.env["DASHBOARD_PASSWORD_HASH"] ?? "", version: "initial" } };
}

export async function saveAdmin(credentials: AdminCredentials, snapshot: AdminSnapshot) {
  if (process.env["SOARES_NETLIFY_RUNTIME"] !== "true") throw new Error("Persistent credentials require Netlify");
  const storage = store();
  const result = await storage.setJSON("credentials", credentials,
    snapshot.etag ? { onlyIfMatch: snapshot.etag } : { onlyIfNew: true });
  if (!result.modified) throw new Error("Concurrent password update");
  // Read back: never acknowledge a password change that was not persisted.
  const saved = await storage.get("credentials", { type: "json", consistency: "strong" });
  if (saved?.version !== credentials.version) throw new Error("Password update was not persisted");
}

export async function loadTeam(): Promise<TeamSnapshot> {
  if (process.env["SOARES_NETLIFY_RUNTIME"] !== "true") return { credentials: null };
  const entry = await store().getWithMetadata("team-credentials", { type: "json" });
  if (!entry) return { credentials: null };
  const data = entry.data as TeamCredentials;
  if (typeof data.user !== "string" || typeof data.passwordHash !== "string" ||
      typeof data.version !== "string" || typeof data.enabled !== "boolean") {
    throw new Error("Invalid team credential record");
  }
  return { credentials: data, etag: entry.etag };
}

export async function saveTeam(credentials: TeamCredentials, snapshot: TeamSnapshot) {
  if (process.env["SOARES_NETLIFY_RUNTIME"] !== "true") throw new Error("Persistent credentials require Netlify");
  const storage = store();
  const result = await storage.setJSON("team-credentials", credentials,
    snapshot.etag ? { onlyIfMatch: snapshot.etag } : { onlyIfNew: true });
  if (!result.modified) throw new Error("Concurrent team update");
  const saved = await storage.get("team-credentials", { type: "json", consistency: "strong" });
  if (saved?.version !== credentials.version) throw new Error("Team update was not persisted");
}
