import { useCallback, useEffect, useMemo, useState } from "react";
import { Users, UserRoundX, CalendarDays, BriefcaseBusiness, RefreshCw, LogOut, LockKeyhole } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableHeader, TableHead, TableBody, TableRow, TableCell } from "@/components/ui/table";
import { leadStatuses, sanitizeLeads, type Lead } from "@/lib/dashboard-data";
import { todayInBrazil, dateKey, inPeriod } from "@/lib/dashboard-analytics";
import { operationalSummary } from "@/lib/operational-data";
import { Panel, PageHeader, MetricCard, EmptyState } from "./dashboard-ui";
import { ChangePassword } from "./change-password";

export function OperationsPanel({ user, onSessionExpired }: { user: string; onSessionExpired: () => void }) {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [updatedAt, setUpdatedAt] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("all");
  const [consultant, setConsultant] = useState("all");
  const [period, setPeriod] = useState("all");
  const [showPassword, setShowPassword] = useState(false);
  const today = todayInBrazil();
  const refresh = useCallback(async () => {
    setLoading(true); setError("");
    try {
      const response = await fetch("/api/dashboard", { cache: "no-store", credentials: "same-origin" });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error ?? "Não foi possível atualizar.");
      if (!data.integration?.authenticated) { setLeads([]); onSessionExpired(); return; }
      if (!data.integration?.connected) throw new Error("A conexão com a planilha está pendente. Peça ao administrador para verificar.");
      setLeads(sanitizeLeads(data.leads ?? [])); setUpdatedAt(data.integration.updatedAt);
    } catch (e) {
      // Fail closed instead of retaining misleading/outdated totals after errors.
      setLeads([]); setUpdatedAt(null); setError(e instanceof Error ? e.message : "Falha na atualização.");
    } finally { setLoading(false); }
  }, [onSessionExpired]);
  useEffect(() => {
    void refresh();
    const timer = window.setInterval(() => void refresh(), 60_000);
    return () => window.clearInterval(timer);
  }, [refresh]);
  const summary = useMemo(() => operationalSummary(leads, today), [leads, today]);
  const periodLeads = leads.filter(l => period === "all" || inPeriod(l.entryDate, period, today));
  const tableSummary = operationalSummary(periodLeads, today);
  const filtered = periodLeads.filter(l => `${l.name} ${l.phone} ${l.email}`.toLowerCase().includes(search.toLowerCase()) &&
    (status === "all" || l.status === status) && (consultant === "all" || (l.consultant.trim() || "Sem atribuição") === consultant));
  const names = [...new Set(leads.map(l => l.consultant.trim() || "Sem atribuição"))].sort();
  const selectClass = "h-10 rounded-md border border-input bg-background px-3 text-sm";
  const date = (value: string) => { const key = dateKey(value); return key ? key.split("-").reverse().join("/") : "—"; };
  async function logout() {
    try { const r = await fetch("/api/dashboard/logout", { method: "POST" }); if (!r.ok) throw new Error(); window.location.reload(); }
    catch { setError("Não foi possível sair. Tente novamente."); }
  }
  return <div className="min-h-screen bg-background text-foreground">
    <header className="border-b border-border px-4 py-5 sm:px-8">
      <div className="mx-auto flex max-w-[1500px] flex-wrap items-center justify-between gap-3">
        <div><p className="font-display font-semibold tracking-widest text-primary">SOARES</p><p className="text-xs text-muted-foreground">Controle de leads e consultores</p></div>
        <div className="flex flex-wrap items-center gap-2"><span className="mr-2 text-sm">{user}</span><Button variant="outline" onClick={() => setShowPassword(v => !v)}><LockKeyhole />Alterar senha</Button><Button variant="outline" onClick={() => void logout()}><LogOut />Sair</Button></div>
      </div>
    </header>
    <main className="mx-auto max-w-[1500px] space-y-6 px-4 py-6 sm:px-8">
      <PageHeader eyebrow="Operação comercial" title="Painel Soares" description="Acompanhe a entrada de leads e a distribuição dos atendimentos entre os consultores." actions={<Button variant="outline" disabled={loading} onClick={() => void refresh()}><RefreshCw />{loading ? "Atualizando…" : "Atualizar"}</Button>} />
      <p role="status" className="text-xs text-muted-foreground">{loading ? "Sincronizando com a planilha…" : updatedAt ? `Atualizado em ${new Date(updatedAt).toLocaleString("pt-BR", { timeZone: "America/Sao_Paulo" })}. Atualização automática a cada minuto.` : "Aguardando conexão."}</p>
      {error && <p role="alert" className="rounded-md border border-warning/40 p-4 text-sm text-warning">{error}</p>}
      {showPassword && <ChangePassword />}
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {[
          { label: "Total de leads", value: summary.total, detail: "Todos os leads válidos", icon: <BriefcaseBusiness /> },
          { label: "Leads de hoje", value: summary.today, detail: date(today), icon: <CalendarDays /> },
          { label: "Leads de ontem", value: summary.yesterday, detail: "Dia anterior", icon: <Users /> },
          { label: "Sem responsável", value: summary.unassigned, detail: "Aguardando distribuição", icon: <UserRoundX /> },
        ].map(m => <MetricCard key={m.label} {...m} value={error ? "—" : String(m.value)} />)}
      </div>
      <p className="text-xs text-muted-foreground">Atualize o status e o consultor responsável na planilha. Este painel acompanha os dados, sem alterar a planilha.</p>
      <div className="flex flex-wrap items-center gap-2"><label className="text-sm" htmlFor="ops-period">Período das tabelas e status</label><select id="ops-period" className={selectClass} value={period} onChange={e => setPeriod(e.target.value)}><option value="all">Todo o histórico</option><option value="7d">Últimos 7 dias</option><option value="30d">Últimos 30 dias</option><option value="90d">Últimos 90 dias</option><option value="year">Este ano</option></select></div>
      <Panel title="Status dos leads" description="Distribuição no período selecionado"><div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">{tableSummary.statuses.map(s => <div key={s.status} className="rounded-md border border-border p-3"><p className="text-xs text-muted-foreground">{s.status}</p><p className="mt-2 text-xl text-primary">{s.count}</p></div>)}</div></Panel>
      <Panel title="Controle dos consultores" description="Volume, etapas de atendimento e taxa de fechamento — sem valores financeiros">
        {!tableSummary.consultants.length ? <EmptyState title="Nenhum atendimento no período" description="Atribua os responsáveis na coluna Consultor da planilha." /> : <Table><TableHeader><TableRow><TableHead>Consultor</TableHead><TableHead>Leads</TableHead>{leadStatuses.map(s => <TableHead className="whitespace-nowrap" key={s}>{s}</TableHead>)}<TableHead>Conversão</TableHead></TableRow></TableHeader><TableBody>{tableSummary.consultants.map(c => <TableRow key={c.name}><TableCell className="whitespace-nowrap font-medium">{c.name}</TableCell><TableCell>{c.leads}</TableCell>{leadStatuses.map(s => <TableCell key={s}>{c.counts[s]}</TableCell>)}<TableCell>{(c.conversion * 100).toLocaleString("pt-BR", { maximumFractionDigits: 1 })}%</TableCell></TableRow>)}</TableBody></Table>}
      </Panel>
      <Panel title="Leads" description={`${filtered.length} contato(s) no filtro selecionado`}>
        <div className="mb-4 grid gap-2 sm:grid-cols-3"><Input aria-label="Buscar lead" placeholder="Nome, telefone ou e-mail" value={search} onChange={e => setSearch(e.target.value)} /><select aria-label="Filtrar status" className={selectClass} value={status} onChange={e => setStatus(e.target.value)}><option value="all">Todos os status</option>{leadStatuses.map(s => <option key={s}>{s}</option>)}</select><select aria-label="Filtrar consultor" className={selectClass} value={consultant} onChange={e => setConsultant(e.target.value)}><option value="all">Todos os consultores</option>{names.map(n => <option key={n}>{n}</option>)}</select></div>
        {!filtered.length ? <EmptyState title="Nenhum lead encontrado" description="Ajuste os filtros ou aguarde novos contatos na planilha." /> : <Table><TableHeader><TableRow>{["Entrada", "Nome", "Contato", "Tipo", "Status", "Consultor", "Próximo retorno", "Observações"].map(s => <TableHead key={s}>{s}</TableHead>)}</TableRow></TableHeader><TableBody>{filtered.map(l => <TableRow key={l.id}><TableCell className="whitespace-nowrap">{date(l.entryDate)}</TableCell><TableCell className="min-w-40 font-medium">{l.name}</TableCell><TableCell className="min-w-40"><p>{l.phone}</p><p className="text-xs text-muted-foreground">{l.email}</p></TableCell><TableCell>{l.financingType}</TableCell><TableCell className="whitespace-nowrap text-primary">{l.status}</TableCell><TableCell>{l.consultant || "Sem responsável"}</TableCell><TableCell className="whitespace-nowrap">{date(l.nextReturn)}</TableCell><TableCell className="min-w-44 whitespace-normal">{l.notes || "—"}</TableCell></TableRow>)}</TableBody></Table>}
      </Panel>
    </main>
  </div>;
}
