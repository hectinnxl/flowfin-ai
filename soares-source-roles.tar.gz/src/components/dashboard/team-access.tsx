import { useEffect, useState, type FormEvent } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Panel } from "./dashboard-ui";

export function TeamAccess() {
  const [user, setUser] = useState("soares");
  const [enabled, setEnabled] = useState(false);
  const [currentPassword, setCurrent] = useState("");
  const [password, setPassword] = useState("");
  const [confirmation, setConfirmation] = useState("");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    void fetch("/api/dashboard/team", { cache: "no-store" }).then(async r => {
      const data = await r.json();
      if (!r.ok) throw new Error(data.error ?? "Não foi possível verificar o acesso da equipe.");
      setUser(data.user); setEnabled(data.enabled);
    }).catch(e => setMessage(e.message));
  }, []);
  async function save(event: FormEvent, activate: boolean) {
    event.preventDefault(); setBusy(true); setMessage("");
    try {
      const response = await fetch("/api/dashboard/team", {
        method: "POST", credentials: "same-origin", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ user, currentPassword, password, confirmation, enabled: activate }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error ?? "Não foi possível salvar.");
      setEnabled(data.enabled); setCurrent(""); setPassword(""); setConfirmation("");
      setMessage(activate ? "Acesso da Soares ativado. Compartilhe o login e a senha por um canal privado." : "Acesso da Soares desativado. Sessões anteriores não serão mais aceitas.");
    } catch (e) { setMessage(e instanceof Error ? e.message : "Falha ao salvar."); }
    finally { setBusy(false); }
  }
  return <Panel className="mt-5" title="Acesso da equipe Soares" description="Painel restrito a leads e consultores. Seu acesso completo não será alterado.">
    <p className="mb-4 text-sm">{enabled ? "Acesso da equipe ativo" : "Acesso da equipe ainda não ativado"}</p>
    <form onSubmit={e => void save(e, true)} className="max-w-md space-y-4">
      <label className="block text-sm">Login da equipe<Input className="mt-1" required minLength={3} maxLength={64} pattern="[a-zA-Z0-9._-]+" autoComplete="off" value={user} onChange={e => setUser(e.target.value)} /></label>
      <label className="block text-sm">Sua senha atual de administrador<Input className="mt-1" required type="password" autoComplete="current-password" maxLength={256} value={currentPassword} onChange={e => setCurrent(e.target.value)} /></label>
      <label className="block text-sm">Senha da equipe<Input className="mt-1" required minLength={12} maxLength={256} type="password" autoComplete="new-password" value={password} onChange={e => setPassword(e.target.value)} /></label>
      <label className="block text-sm">Confirmar senha da equipe<Input className="mt-1" required minLength={12} maxLength={256} type="password" autoComplete="new-password" value={confirmation} onChange={e => setConfirmation(e.target.value)} /></label>
      <p className="text-xs text-muted-foreground">Use uma senha exclusiva, diferente da sua. Salvar substitui a senha da equipe e encerra as sessões antigas. A equipe não recebe gastos, receita ou dados de campanhas.</p>
      <div className="flex flex-wrap gap-2"><Button type="submit" disabled={busy}>{busy ? "Salvando…" : enabled ? "Atualizar acesso da equipe" : "Ativar acesso da equipe"}</Button>
        {enabled && <Button type="button" variant="outline" disabled={busy || !currentPassword} onClick={e => void save(e, false)}>Desativar acesso</Button>}
      </div>
      {message && <p role="status" className="text-sm text-primary">{message}</p>}
    </form>
  </Panel>;
}
