import { Link, useRouterState } from "@tanstack/react-router";
import {
  BarChart3,
  BriefcaseBusiness,
  CircleDollarSign,
  LayoutDashboard,
  Menu,
  Settings,
  TrendingUp,
  Users,
  X,
} from "lucide-react";
import { useState, type ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { DashboardProvider, useDashboard } from "./dashboard-context";

const navItems = [
  { to: "/", label: "Visão Geral", icon: LayoutDashboard },
  { to: "/consultores", label: "Consultores", icon: Users },
  { to: "/leads", label: "Leads", icon: BriefcaseBusiness },
  { to: "/campanhas", label: "Campanhas", icon: BarChart3 },
  { to: "/financeiro", label: "Financeiro", icon: CircleDollarSign },
  { to: "/configuracoes", label: "Configurações", icon: Settings },
] as const;

function BrandMark() {
  return (
    <div className="grid size-10 shrink-0 place-items-center rounded-md border border-primary/40 bg-primary/10 font-display text-lg font-semibold text-primary">
      S
    </div>
  );
}

function ConnectionStatus() {
  const { integration, loading } = useDashboard();
  return (
    <span className="hidden items-center gap-1.5 text-xs text-muted-foreground md:flex">
      <span
        className={`size-1.5 rounded-full ${integration.connected ? "bg-success" : "bg-warning"}`}
      />
      {loading
        ? "Sincronizando"
        : integration.connected
          ? "Google Sheets conectado"
          : "Integração pendente"}
    </span>
  );
}

export function DashboardShell({ children }: { children: ReactNode }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const pathname = useRouterState({ select: (state) => state.location.pathname });

  return (
    <DashboardProvider>
      <div className="min-h-screen bg-background text-foreground">
        <aside className="fixed inset-y-0 left-0 z-40 hidden w-[76px] flex-col items-center border-r border-border bg-sidebar py-5 lg:flex">
          <BrandMark />
          <nav className="mt-10 flex flex-1 flex-col gap-2" aria-label="Navegação principal">
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  aria-label={item.label}
                  title={item.label}
                  className="group relative grid size-11 place-items-center rounded-md text-muted-foreground transition-all hover:bg-accent hover:text-primary"
                  activeProps={{ className: "bg-primary/10 text-primary ring-1 ring-primary/25" }}
                >
                  <Icon className="size-[18px]" strokeWidth={1.7} />
                  <span className="pointer-events-none absolute left-14 z-50 whitespace-nowrap rounded-md border border-border bg-popover px-2.5 py-1.5 text-xs text-popover-foreground opacity-0 shadow-xl transition-opacity group-hover:opacity-100">
                    {item.label}
                  </span>
                </Link>
              );
            })}
          </nav>
          <div className="grid size-9 place-items-center rounded-full border border-primary/30 bg-primary/10 text-xs font-semibold text-primary">
            RA
          </div>
        </aside>

        {menuOpen && (
          <button
            aria-label="Fechar menu"
            className="fixed inset-0 z-40 bg-overlay lg:hidden"
            onClick={() => setMenuOpen(false)}
          />
        )}
        <aside
          inert={!menuOpen}
          aria-hidden={!menuOpen}
          className={`fixed inset-y-0 left-0 z-50 w-72 border-r border-border bg-sidebar p-5 transition-transform lg:hidden ${menuOpen ? "translate-x-0" : "-translate-x-full"}`}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <BrandMark />
              <span className="font-display text-base">SOARES</span>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setMenuOpen(false)}
              aria-label="Fechar menu"
            >
              <X />
            </Button>
          </div>
          <nav className="mt-8 space-y-1" aria-label="Navegação móvel">
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  onClick={() => setMenuOpen(false)}
                  className="flex items-center gap-3 rounded-md px-3 py-3 text-sm text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
                  activeProps={{ className: "bg-primary/10 text-primary" }}
                >
                  <Icon className="size-[18px]" />
                  {item.label}
                </Link>
              );
            })}
          </nav>
        </aside>

        <div className="lg:pl-[76px]">
          <header className="sticky top-0 z-30 grid h-[72px] grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-3 border-b border-border bg-background/90 px-4 backdrop-blur-xl sm:px-6 lg:px-8">
            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden"
              onClick={() => setMenuOpen(true)}
              aria-label="Abrir menu"
            >
              <Menu />
            </Button>
            <div className="min-w-0">
              <div className="flex min-w-0 items-baseline gap-2">
                <span className="truncate font-display text-sm font-semibold tracking-[0.12em] sm:text-base">
                  SOARES SOLUÇÕES FINANCEIRAS
                </span>
                <span className="hidden text-border sm:inline">|</span>
                <span className="hidden truncate text-xs text-muted-foreground sm:inline">
                  Revenue Analytics
                </span>
              </div>
            </div>
            <div className="flex shrink-0 items-center gap-2">
              <ConnectionStatus />
              <TrendingUp className="size-4 text-primary" />
            </div>
          </header>
          <main key={pathname} className="animate-page-in px-4 py-6 sm:px-6 lg:px-8 lg:py-8">
            {children}
          </main>
        </div>
      </div>
    </DashboardProvider>
  );
}
