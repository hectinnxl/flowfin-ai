import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { demoLeads, sanitizeLeads, type Consultant, type Lead } from "@/lib/dashboard-data";
import {
  campaignTotals,
  inPeriod,
  summarizeConsultants,
  summarizeDaily,
  todayInBrazil,
  type SpendEntry,
} from "@/lib/dashboard-analytics";

type Integration = {
  configured: boolean;
  authenticated: boolean;
  connected: boolean;
  updatedAt: string | null;
};
type DashboardContextValue = {
  demoMode: boolean;
  setDemoMode: (value: boolean) => void;
  leads: Lead[];
  consultants: Consultant[];
  daily: ReturnType<typeof summarizeDaily>;
  period: string;
  setPeriod: (value: string) => void;
  today: string;
  campaignSpend: Record<string, number>;
  investment: number;
  setCampaignSpend: (id: string, amount: number, date: string) => void;
  spendForDate: (id: string, date: string) => number;
  integration: Integration;
  loading: boolean;
  error: string;
  refresh: () => Promise<void>;
};
const DashboardContext = createContext<DashboardContextValue | null>(null);

export function DashboardProvider({ children }: { children: ReactNode }) {
  const [demoMode, setDemoMode] = useState(false);
  const [period, setPeriod] = useState("30d");
  const [today] = useState(() => todayInBrazil());
  const [realLeads, setRealLeads] = useState<Lead[]>([]);
  const [realSpend, setRealSpend] = useState<SpendEntry[]>([]);
  const [demoSpend, setDemoSpend] = useState<SpendEntry[]>([
    { date: today, campaignId: "creative-01", amount: 210 },
    { date: today, campaignId: "creative-02", amount: 210 },
  ]);
  const [integration, setIntegration] = useState<Integration>({
    configured: false,
    authenticated: false,
    connected: false,
    updatedAt: null,
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function refresh() {
    setLoading(true);
    setError("");
    try {
      const response = await fetch("/api/dashboard", {
        credentials: "same-origin",
        cache: "no-store",
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error ?? "Não foi possível sincronizar os dados.");
      setIntegration(data.integration);
      setRealLeads(sanitizeLeads(data.leads ?? []));
      setRealSpend(data.spend ?? []);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Falha na sincronização.");
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => {
    void refresh();
  }, []);

  const value = useMemo<DashboardContextValue>(() => {
    const exampleLeads = demoLeads.map((lead, index) => {
      const day = new Date(today + "T12:00:00Z");
      day.setUTCDate(day.getUTCDate() - (demoLeads.length - index - 1));
      const entryDate = day.toISOString().slice(0, 10);
      return {
        ...lead,
        entryDate,
        lastContact: lead.lastContact ? today : "",
        nextReturn: lead.nextReturn ? entryDate : "",
      };
    });
    const leads = sanitizeLeads(demoMode ? exampleLeads : realLeads).filter((lead) =>
      inPeriod(lead.entryDate, period, today),
    );
    const spend = demoMode ? demoSpend : realSpend;
    const campaignSpend = campaignTotals(spend, period, today);
    return {
      demoMode,
      setDemoMode,
      leads,
      consultants: summarizeConsultants(leads),
      daily: summarizeDaily(leads),
      period,
      setPeriod,
      today,
      campaignSpend,
      investment: Object.values(campaignSpend).reduce((sum, amount) => sum + amount, 0),
      integration,
      loading,
      error,
      refresh,
      spendForDate: (id, date) =>
        spend
          .filter((e) => e.campaignId === id && e.date === date)
          .reduce((sum, e) => sum + e.amount, 0),
      setCampaignSpend: (id, amount, date) => {
        const update = demoMode ? setDemoSpend : setRealSpend;
        update((current) => [
          ...current.filter((e) => !(e.campaignId === id && e.date === date)),
          { campaignId: id, date, amount: Number.isFinite(amount) ? Math.max(0, amount) : 0 },
        ]);
      },
    };
  }, [demoMode, period, today, realLeads, realSpend, demoSpend, integration, loading, error]);
  return <DashboardContext.Provider value={value}>{children}</DashboardContext.Provider>;
}

export function useDashboard() {
  const context = useContext(DashboardContext);
  if (!context) throw new Error("useDashboard deve ser usado dentro de DashboardProvider");
  return context;
}
