import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  BadgeDollarSign,
  Briefcase,
  CircleDollarSign,
  MousePointerClick,
  ReceiptText,
  Target,
  Users,
} from "lucide-react";
import { leadStatuses } from "@/lib/dashboard-data";
import {
  DashboardControls,
  DemoNotice,
  EmptyState,
  MetricCard,
  PageHeader,
  Panel,
  formatCurrency,
} from "./dashboard-ui";
import { useDashboard } from "./dashboard-context";

export function OverviewPage() {
  const { demoMode, leads, investment, daily } = useDashboard();
  const closed = leads.filter((lead) => lead.status === "Fechado");
  const revenue = closed.reduce((sum, lead) => sum + lead.closedContractValue, 0);
  const conversion = leads.length ? (closed.length / leads.length) * 100 : 0;
  const cpl = leads.length ? investment / leads.length : 0;
  const cac = closed.length ? investment / closed.length : 0;
  const funnel = leadStatuses
    .map((status) => ({ status, value: leads.filter((lead) => lead.status === status).length }))
    .filter((item) => item.value || !demoMode);
  const creative = ["Criativo 01 – Veículo", "Criativo 02 – Contrato"].map((name) => ({
    name: name.replace("Criativo ", "C"),
    leads: leads.filter((lead) => lead.creative === name).length,
    fechados: leads.filter((lead) => lead.creative === name && lead.status === "Fechado").length,
  }));
  const rows = leads.map(
    ({ name, entryDate, status, consultant, creative: campaign, closedContractValue }) => ({
      Nome: name,
      Entrada: entryDate,
      Status: status,
      Consultor: consultant,
      Campanha: campaign,
      "Valor fechado": closedContractValue,
    }),
  );
  return (
    <>
      <PageHeader
        eyebrow="Inteligência comercial"
        title="Visão Geral"
        description="Uma leitura objetiva da operação, da entrada do lead ao contrato fechado."
        actions={<DashboardControls exportRows={rows} exportName="soares-visao-geral" />}
      />
      <DemoNotice />
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4 2xl:grid-cols-7">
        <MetricCard
          label={demoMode ? "Leads de exemplo" : "Leads reais"}
          value={String(leads.length)}
          detail="Registros válidos"
          icon={<Users />}
        />
        <MetricCard
          label="Investimento"
          value={formatCurrency(investment)}
          detail="Gasto efetivo"
          icon={<CircleDollarSign />}
        />
        <MetricCard
          label="CPL"
          value={formatCurrency(cpl)}
          detail="Custo por lead"
          icon={<MousePointerClick />}
        />
        <MetricCard
          label="Contratos fechados"
          value={String(closed.length)}
          detail="Vendas concluídas"
          icon={<Briefcase />}
        />
        <MetricCard
          label="Receita contratada"
          value={formatCurrency(revenue)}
          detail="Valor dos contratos"
          icon={<BadgeDollarSign />}
        />
        <MetricCard
          label="Taxa de conversão"
          value={`${conversion.toFixed(1)}%`}
          detail="Lead para contrato"
          icon={<Target />}
        />
        <MetricCard
          label="CAC"
          value={formatCurrency(cac)}
          detail="Custo por aquisição"
          icon={<ReceiptText />}
        />
      </div>
      <div className="mt-5 grid gap-5 xl:grid-cols-[1.55fr_1fr]">
        <Panel title="Evolução diária" description="Leads recebidos no período selecionado">
          {!leads.length ? (
            <EmptyState
              title="Sem dados para o período"
              description="A evolução aparecerá após a integração trazer os primeiros leads válidos."
            />
          ) : (
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={daily} margin={{ left: -20, right: 6 }}>
                  <defs>
                    <linearGradient id="goldArea" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="var(--chart-1)" stopOpacity={0.35} />
                      <stop offset="100%" stopColor="var(--chart-1)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid stroke="var(--chart-grid)" vertical={false} />
                  <XAxis
                    dataKey="date"
                    stroke="var(--muted-foreground)"
                    fontSize={11}
                    tickLine={false}
                    axisLine={false}
                  />
                  <YAxis
                    stroke="var(--muted-foreground)"
                    fontSize={11}
                    tickLine={false}
                    axisLine={false}
                  />
                  <Tooltip
                    contentStyle={{
                      background: "var(--popover)",
                      border: "1px solid var(--border)",
                      borderRadius: 6,
                    }}
                  />
                  <Area
                    type="monotone"
                    dataKey="leads"
                    name="Leads"
                    stroke="var(--chart-1)"
                    strokeWidth={2}
                    fill="url(#goldArea)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          )}
        </Panel>
        <Panel title="Funil por estágio" description="Distribuição atual dos leads">
          {!leads.length ? (
            <EmptyState
              compact
              title="Funil ainda vazio"
              description="Cada etapa será preenchida conforme o atendimento avançar."
            />
          ) : (
            <div className="space-y-3">
              {funnel.map((item, index) => (
                <div key={item.status}>
                  <div className="mb-1.5 flex justify-between text-xs">
                    <span className="text-muted-foreground">{item.status}</span>
                    <span className="font-medium">{item.value}</span>
                  </div>
                  <div className="h-1.5 overflow-hidden rounded-full bg-muted">
                    <div
                      className="h-full rounded-full bg-primary transition-all"
                      style={{ width: `${(item.value / Math.max(1, leads.length)) * 100}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          )}
        </Panel>
      </div>
      <Panel
        className="mt-5"
        title="Conversões por criativo"
        description="Volume e contratos por origem criativa"
      >
        {!leads.length ? (
          <EmptyState
            title="Nenhuma conversão registrada"
            description="As campanhas aparecerão aqui quando houver dados carregados e identificados."
          />
        ) : (
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={creative}>
                <CartesianGrid stroke="var(--chart-grid)" vertical={false} />
                <XAxis
                  dataKey="name"
                  stroke="var(--muted-foreground)"
                  fontSize={11}
                  tickLine={false}
                  axisLine={false}
                />
                <YAxis
                  stroke="var(--muted-foreground)"
                  fontSize={11}
                  tickLine={false}
                  axisLine={false}
                />
                <Tooltip
                  contentStyle={{
                    background: "var(--popover)",
                    border: "1px solid var(--border)",
                    borderRadius: 6,
                  }}
                />
                <Bar dataKey="leads" name="Leads" fill="var(--chart-2)" radius={[3, 3, 0, 0]} />
                <Bar
                  dataKey="fechados"
                  name="Fechados"
                  fill="var(--chart-1)"
                  radius={[3, 3, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}
      </Panel>
    </>
  );
}
