import { useState } from "react";
import { BarChart3, CircleDollarSign, MousePointerClick } from "lucide-react";
import { Input } from "@/components/ui/input";
import { campaignDefinitions } from "@/lib/dashboard-data";
import {
  DashboardControls,
  DemoNotice,
  MetricCard,
  PageHeader,
  Panel,
  formatCurrency,
} from "./dashboard-ui";
import { useDashboard } from "./dashboard-context";

export function CampaignsPage() {
  const { campaignSpend, setCampaignSpend, spendForDate, leads, investment, today } =
    useDashboard();
  const [spendDate, setSpendDate] = useState(today);
  const assigned = leads.filter((l) =>
    campaignDefinitions.some((c) => c.name === l.creative),
  ).length;
  return (
    <>
      <PageHeader
        eyebrow="Aquisição"
        title="Campanhas"
        description="Compare o orçamento planejado ao gasto efetivo registrado para cada criativo."
        actions={
          <DashboardControls
            exportRows={campaignDefinitions.map((c) => ({
              Campanha: c.name,
              "Orçamento diário": c.dailyBudget,
              "Gasto efetivo": campaignSpend[c.id] ?? 0,
            }))}
            exportName="soares-campanhas"
          />
        }
      />
      <DemoNotice />
      <div className="grid gap-3 sm:grid-cols-3">
        <MetricCard
          label="Orçamento diário"
          value={formatCurrency(100)}
          detail="Total planejado"
          icon={<CircleDollarSign />}
        />
        <MetricCard
          label="Gasto efetivo"
          value={formatCurrency(investment)}
          detail="No período selecionado"
          icon={<BarChart3 />}
        />
        <MetricCard
          label="Leads atribuídos"
          value={String(assigned)}
          detail="Nos dois criativos"
          icon={<MousePointerClick />}
        />
      </div>
      <div className="mt-5 flex flex-wrap items-center gap-3">
        <label htmlFor="spend-date" className="text-sm text-muted-foreground">
          Data do gasto
        </label>
        <Input
          id="spend-date"
          type="date"
          max={today}
          value={spendDate}
          onChange={(e) => {
            if (e.target.value) setSpendDate(e.target.value);
          }}
          className="w-44"
        />
      </div>
      <div className="mt-5 grid gap-5 lg:grid-cols-2">
        {campaignDefinitions.map((campaign, index) => {
          const spend = spendForDate(campaign.id, spendDate);
          const campaignLeads = leads.filter((l) => l.creative === campaign.name).length;
          const total = campaignSpend[campaign.id] ?? 0;
          return (
            <Panel
              key={campaign.id}
              title={campaign.name}
              description={campaign.category}
              action={
                <span className="text-[10px] font-semibold uppercase tracking-[0.16em] text-primary">
                  Planejamento
                </span>
              }
            >
              <div className="space-y-5">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-xs text-muted-foreground">Orçamento planejado</p>
                    <p className="mt-1 font-display text-2xl">
                      R$ 50<span className="text-sm text-muted-foreground">/dia</span>
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Leads atribuídos</p>
                    <p className="mt-1 font-display text-2xl">{campaignLeads}</p>
                  </div>
                </div>
                <div>
                  <label
                    htmlFor={"spend-" + index}
                    className="mb-2 block text-xs font-medium text-muted-foreground"
                  >
                    Gasto efetivo na data selecionada
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">
                      R$
                    </span>
                    <Input
                      id={"spend-" + index}
                      type="number"
                      min="0"
                      step="0.01"
                      className="pl-10"
                      value={spend || ""}
                      placeholder="0,00"
                      onChange={(e) =>
                        setCampaignSpend(campaign.id, Number(e.target.value), spendDate)
                      }
                    />
                  </div>
                  <p className="mt-2 text-[11px] text-muted-foreground">
                    Ajuste nesta sessão. Recarregar ou sincronizar restaura os valores da fonte.
                  </p>
                </div>
                <div className="flex justify-between border-t border-border pt-4 text-xs">
                  <span className="text-muted-foreground">Total no período</span>
                  <strong>{formatCurrency(total)}</strong>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-muted-foreground">CPL</span>
                  <strong>{campaignLeads ? formatCurrency(total / campaignLeads) : "—"}</strong>
                </div>
              </div>
            </Panel>
          );
        })}
      </div>
    </>
  );
}
