import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Banknote, CircleDollarSign, Receipt, Scale } from "lucide-react";
import {
  DashboardControls,
  DemoNotice,
  EmptyState,
  MetricCard,
  PageHeader,
  Panel,
  formatCurrency,
} from "./dashboard-ui";
import { useDashboard } from "./dashboard-context";

export function FinancePage() {
  const { leads, investment, daily } = useDashboard();
  const revenue = leads
    .filter((l) => l.status === "Fechado")
    .reduce((sum, l) => sum + l.closedContractValue, 0);
  const result = revenue - investment;
  return (
    <>
      <PageHeader
        eyebrow="Saúde financeira"
        title="Financeiro"
        description="Consolide receita contratada e custos informados sem confundir projeção com resultado real."
        actions={
          <DashboardControls
            exportRows={leads
              .filter((l) => l.status === "Fechado")
              .map((l) => ({
                Cliente: l.name,
                "Receita contratada": l.closedContractValue,
                Consultor: l.consultant,
                Campanha: l.creative,
              }))}
            exportName="soares-financeiro"
          />
        }
      />
      <DemoNotice />
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <MetricCard
          label="Receita contratada"
          value={formatCurrency(revenue)}
          detail="Contratos fechados"
          icon={<Banknote />}
        />
        <MetricCard
          label="Investimento"
          value={formatCurrency(investment)}
          detail="Gasto efetivo informado"
          icon={<CircleDollarSign />}
        />
        <MetricCard
          label="Custos totais"
          value={formatCurrency(investment)}
          detail="Custos disponíveis"
          icon={<Receipt />}
        />
        <MetricCard
          label="Saldo contratual"
          value={formatCurrency(result)}
          detail="Contratos menos mídia; não é lucro"
          icon={<Scale />}
        />
      </div>
      <div className="mt-5 grid gap-5 xl:grid-cols-[1.5fr_1fr]">
        <Panel title="Receita no período" description="Evolução diária dos contratos fechados">
          {!leads.length ? (
            <EmptyState
              title="Sem movimentação financeira"
              description="A receita será exibida quando existirem contratos fechados válidos."
            />
          ) : (
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={daily} margin={{ left: 0, right: 8 }}>
                  <defs>
                    <linearGradient id="revenueArea" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="var(--chart-1)" stopOpacity={0.35} />
                      <stop offset="100%" stopColor="var(--chart-1)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid stroke="var(--chart-grid)" vertical={false} />
                  <XAxis
                    dataKey="date"
                    stroke="var(--muted-foreground)"
                    fontSize={11}
                    axisLine={false}
                    tickLine={false}
                  />
                  <YAxis
                    stroke="var(--muted-foreground)"
                    fontSize={11}
                    axisLine={false}
                    tickLine={false}
                    tickFormatter={(v) => `R$${v / 1000}k`}
                  />
                  <Tooltip
                    formatter={(value) => formatCurrency(Number(value))}
                    contentStyle={{
                      background: "var(--popover)",
                      border: "1px solid var(--border)",
                      borderRadius: 6,
                    }}
                  />
                  <Area
                    dataKey="revenue"
                    name="Receita"
                    stroke="var(--chart-1)"
                    strokeWidth={2}
                    fill="url(#revenueArea)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          )}
        </Panel>
        <Panel title="Composição" description="Proporção entre receita e custos">
          <div className="flex min-h-64 flex-col justify-center space-y-5">
            <div>
              <div className="mb-2 flex justify-between text-xs">
                <span className="text-muted-foreground">Receita contratada</span>
                <span>{formatCurrency(revenue)}</span>
              </div>
              <div className="h-2 rounded-full bg-muted">
                <div
                  className="h-full rounded-full bg-primary"
                  style={{ width: revenue ? "100%" : "0%" }}
                />
              </div>
            </div>
            <div>
              <div className="mb-2 flex justify-between text-xs">
                <span className="text-muted-foreground">Custos informados</span>
                <span>{formatCurrency(investment)}</span>
              </div>
              <div className="h-2 rounded-full bg-muted">
                <div
                  className="h-full rounded-full bg-chart-2"
                  style={{
                    width: revenue ? `${Math.min(100, (investment / revenue) * 100)}%` : "0%",
                  }}
                />
              </div>
            </div>
            <p className="border-t border-border pt-4 text-xs leading-relaxed text-muted-foreground">
              Valores planejados não são tratados como gasto. O saldo considera valor nominal dos
              contratos menos mídia. Não representa receita recebida, comissão nem lucro líquido.
            </p>
          </div>
        </Panel>
      </div>
    </>
  );
}
