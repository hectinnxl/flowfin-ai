import { Search, Trophy } from "lucide-react";
import { useMemo, useState } from "react";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DashboardControls,
  DemoNotice,
  EmptyState,
  PageHeader,
  Panel,
  formatCurrency,
} from "./dashboard-ui";
import { useDashboard } from "./dashboard-context";

export function ConsultantsPage() {
  const { consultants } = useDashboard();
  const [search, setSearch] = useState("");
  const filtered = useMemo(
    () => consultants.filter((item) => item.name.toLowerCase().includes(search.toLowerCase())),
    [consultants, search],
  );
  return (
    <>
      <PageHeader
        eyebrow="Performance da equipe"
        title="Consultores"
        description="Acompanhe volume, avanço comercial e resultado por responsável, sem rankings artificiais."
        actions={
          <DashboardControls
            exportRows={filtered.map(({ name, leads, contacts, proposals, closed, revenue }) => ({
              Nome: name,
              Leads: leads,
              Contatos: contacts,
              Propostas: proposals,
              Fechados: closed,
              Receita: revenue,
            }))}
            exportName="soares-consultores"
          />
        }
      />
      <DemoNotice />
      <div className="mb-5 grid gap-3 md:grid-cols-[minmax(0,360px)_1fr]">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
            placeholder="Buscar consultor"
          />
        </div>
        <div className="flex items-center gap-2 rounded-md border border-border bg-card px-4 text-xs text-muted-foreground">
          <Trophy className="size-4 text-primary" />O ranking considera contratos fechados e, no
          desempate, receita contratada.
        </div>
      </div>
      <Panel
        title="Desempenho por consultor"
        description="Resultados consolidados no período selecionado"
      >
        {!filtered.length ? (
          <EmptyState
            title="Nenhum consultor com dados"
            description="O ranking será formado apenas quando houver leads válidos atribuídos à equipe."
          />
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Posição</TableHead>
                <TableHead>Consultor</TableHead>
                <TableHead>Leads</TableHead>
                <TableHead>Contatos</TableHead>
                <TableHead>Propostas</TableHead>
                <TableHead>Fechados</TableHead>
                <TableHead>Conversão</TableHead>
                <TableHead className="text-right">Receita</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {[...filtered]
                .sort((a, b) => b.closed - a.closed || b.revenue - a.revenue)
                .map((item, index) => (
                  <TableRow key={item.id}>
                    <TableCell className="text-primary">
                      {String(index + 1).padStart(2, "0")}
                    </TableCell>
                    <TableCell className="font-medium">{item.name}</TableCell>
                    <TableCell>{item.leads}</TableCell>
                    <TableCell>{item.contacts}</TableCell>
                    <TableCell>{item.proposals}</TableCell>
                    <TableCell>{item.closed}</TableCell>
                    <TableCell>
                      {item.leads ? `${((item.closed / item.leads) * 100).toFixed(1)}%` : "0,0%"}
                    </TableCell>
                    <TableCell className="text-right font-medium">
                      {formatCurrency(item.revenue)}
                    </TableCell>
                  </TableRow>
                ))}
            </TableBody>
          </Table>
        )}
      </Panel>
    </>
  );
}
