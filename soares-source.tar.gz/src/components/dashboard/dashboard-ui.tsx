import { CalendarDays, Database, Download, FlaskConical, Inbox, LoaderCircle } from "lucide-react";
import { useState, type ReactNode } from "react";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { useDashboard } from "./dashboard-context";
import { csvText } from "@/lib/dashboard-analytics";

export function formatCurrency(value: number) {
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(value);
}

export function PageHeader({
  eyebrow,
  title,
  description,
  actions,
}: {
  eyebrow: string;
  title: string;
  description: string;
  actions?: ReactNode;
}) {
  return (
    <div className="mb-7 grid grid-cols-1 items-end gap-5 xl:grid-cols-[minmax(0,1fr)_auto]">
      <div className="min-w-0">
        <p className="mb-2 text-[10px] font-semibold uppercase tracking-[0.22em] text-primary">
          {eyebrow}
        </p>
        <h1 className="font-display text-3xl font-medium text-foreground sm:text-4xl">{title}</h1>
        <p className="mt-2 max-w-2xl text-sm leading-relaxed text-muted-foreground">
          {description}
        </p>
      </div>
      <div className="flex min-w-0 flex-wrap items-center gap-2">{actions}</div>
    </div>
  );
}

export function DashboardControls({
  exportRows,
  exportName = "soares-dados",
  exportColumns,
}: {
  exportRows?: Record<string, unknown>[];
  exportName?: string;
  exportColumns?: string[];
}) {
  const { demoMode, setDemoMode, period, setPeriod } = useDashboard();
  const [exported, setExported] = useState(false);
  const exportCsv = () => {
    const rows = exportRows ?? [];
    const headers =
      exportColumns ??
      (rows[0]
        ? Object.keys(rows[0])
        : ["Nome completo", "Data de entrada", "Status atendimento", "Consultor"]);
    const csv = csvText(rows, headers);
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `${exportName}${demoMode ? "-demonstracao" : ""}.csv`;
    anchor.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
    setExported(true);
    window.setTimeout(() => setExported(false), 1800);
  };
  return (
    <>
      <div
        className={`flex h-9 items-center gap-2 rounded-md border px-3 ${demoMode ? "border-warning/50 bg-warning/10" : "border-border bg-card"}`}
      >
        {demoMode ? (
          <FlaskConical className="size-3.5 text-warning" />
        ) : (
          <Database className="size-3.5 text-success" />
        )}
        <span className="hidden text-xs font-medium sm:inline">
          {demoMode ? "Modo demonstração" : "Dados reais"}
        </span>
        <Switch
          checked={demoMode}
          onCheckedChange={setDemoMode}
          aria-label="Alternar modo demonstração"
        />
      </div>
      <Select value={period} onValueChange={setPeriod}>
        <SelectTrigger className="w-[142px]">
          <CalendarDays className="mr-2 size-3.5 text-primary" />
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="7d">Últimos 7 dias</SelectItem>
          <SelectItem value="30d">Últimos 30 dias</SelectItem>
          <SelectItem value="90d">Últimos 90 dias</SelectItem>
          <SelectItem value="year">Este ano</SelectItem>
        </SelectContent>
      </Select>
      <Button variant="outline" onClick={exportCsv} className="shrink-0">
        <Download />
        {exported ? "Exportado" : "Exportar CSV"}
      </Button>
    </>
  );
}

export function DemoNotice() {
  const { demoMode, loading, error } = useDashboard();
  if (!demoMode && loading) return <LoadingSkeleton />;
  if (!demoMode && error)
    return (
      <div
        role="alert"
        className="mb-5 rounded-md border border-warning/40 p-4 text-sm text-warning"
      >
        {error} Abra Configurações para verificar a conexão.
      </div>
    );
  if (!demoMode) return null;
  return (
    <div className="mb-6 flex items-start gap-3 rounded-md border border-warning/35 bg-warning/10 px-4 py-3 text-sm text-warning">
      <FlaskConical className="mt-0.5 size-4 shrink-0" />
      <div>
        <strong>Ambiente demonstrativo.</strong> Os números desta visualização são exemplos e não
        representam resultados reais da SOARES.
      </div>
    </div>
  );
}

export function MetricCard({
  label,
  value,
  detail,
  icon,
}: {
  label: string;
  value: string;
  detail: string;
  icon: ReactNode;
}) {
  return (
    <div className="metric-card group">
      <div className="flex items-start justify-between gap-4">
        <span className="grid size-9 place-items-center rounded-md bg-primary/10 text-primary transition-colors group-hover:bg-primary/15">
          {icon}
        </span>
        <span className="text-[10px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
          Período
        </span>
      </div>
      <p className="mt-5 text-xs font-medium uppercase tracking-[0.1em] text-muted-foreground">
        {label}
      </p>
      <p className="mt-2 font-display text-[clamp(1.65rem,2.4vw,2.4rem)] font-medium leading-none text-foreground">
        {value}
      </p>
      <p className="mt-3 text-xs text-muted-foreground">{detail}</p>
    </div>
  );
}

export function Panel({
  title,
  description,
  action,
  children,
  className = "",
}: {
  title: string;
  description?: string;
  action?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  return (
    <section className={`panel ${className}`}>
      <div className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-4 border-b border-border px-5 py-4 sm:px-6">
        <div className="min-w-0">
          <h2 className="font-display text-lg font-medium">{title}</h2>
          {description && <p className="mt-1 text-xs text-muted-foreground">{description}</p>}
        </div>
        {action}
      </div>
      <div className="p-5 sm:p-6">{children}</div>
    </section>
  );
}

export function EmptyState({
  title,
  description,
  compact = false,
}: {
  title: string;
  description: string;
  compact?: boolean;
}) {
  return (
    <div
      className={`flex flex-col items-center justify-center text-center ${compact ? "min-h-44" : "min-h-64"}`}
    >
      <div className="grid size-11 place-items-center rounded-full border border-primary/20 bg-primary/5 text-primary">
        <Inbox className="size-5" />
      </div>
      <p className="mt-4 text-sm font-medium text-foreground">{title}</p>
      <p className="mt-1 max-w-sm text-xs leading-relaxed text-muted-foreground">{description}</p>
    </div>
  );
}

export function LoadingSkeleton() {
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 text-xs text-muted-foreground">
        <LoaderCircle className="size-3.5 animate-spin text-primary" />
        Carregando dados
      </div>
      <div className="h-3 w-full animate-pulse rounded bg-muted" />
      <div className="h-3 w-4/5 animate-pulse rounded bg-muted" />
      <div className="h-3 w-2/3 animate-pulse rounded bg-muted" />
    </div>
  );
}
