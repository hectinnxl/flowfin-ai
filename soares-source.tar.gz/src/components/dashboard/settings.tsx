import { useState, type FormEvent } from "react";
import { Check, FileSpreadsheet, LockKeyhole, RefreshCw, LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PageHeader, Panel } from "./dashboard-ui";
import { useDashboard } from "./dashboard-context";
import { ChangePassword } from "./change-password";

const fields = [
  "Data de entrada",
  "Nome completo",
  "WhatsApp/Telefone",
  "Email",
  "Tipo financiamento",
  "Valor aproximado parcela",
  "Origem",
  "Status atendimento",
  "Consultor",
  "Observações",
  "ID lead TikTok",
  "TikTok Lead ID",
  "TikTok Lead Status",
  "Último contato",
  "Próximo retorno",
  "Valor contrato fechado",
  "Criativo/campanha",
];

export function SettingsPage() {
  const { integration, refresh, loading, error } = useDashboard();
  const [user, setUser] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const [submitting, setSubmitting] = useState(false);
  async function login(event: FormEvent) {
    event.preventDefault();
    setSubmitting(true);
    setMessage("");
    try {
      const response = await fetch("/api/dashboard/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ user, password }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error ?? "Não foi possível entrar.");
      setPassword("");
      await refresh();
    } catch (err) {
      setMessage(err instanceof Error ? err.message : "Falha ao entrar.");
    } finally {
      setSubmitting(false);
    }
  }
  async function logout() {
    const response = await fetch("/api/dashboard/logout", { method: "POST" });
    if (response.ok) window.location.reload();
    else setMessage("Não foi possível sair. Tente novamente.");
  }
  return (
    <>
      <PageHeader
        eyebrow="Administração"
        title="Configurações de integração"
        description="Sincronização protegida com a fonte operacional da SOARES."
      />
      <div className="mb-5 rounded-md border border-primary/30 bg-primary/5 px-4 py-3">
        <p className="text-sm font-medium text-primary">
          {integration.connected
            ? "Google Sheets conectado"
            : integration.configured
              ? "Conexão configurada — entre para sincronizar"
              : "Integração pendente"}
        </p>
        <p className="mt-1 text-xs text-muted-foreground">
          {integration.updatedAt
            ? "Última leitura: " +
              new Date(integration.updatedAt).toLocaleString("pt-BR", {
                timeZone: "America/Sao_Paulo",
              })
            : "Os dados reais serão carregados após configurar as credenciais no servidor."}
        </p>
      </div>
      <div className="grid gap-5 xl:grid-cols-[1.2fr_1fr]">
        <Panel title="Google Sheets" description="Leitura autenticada da planilha operacional">
          <div className="mb-5 flex items-start gap-3 rounded-md border border-border p-4">
            <FileSpreadsheet className="size-5 text-primary" />
            <div>
              <p className="text-sm font-medium">Planilha operacional SOARES</p>
              <p className="mt-1 text-xs text-muted-foreground">Leads, atendimento e contratos</p>
            </div>
          </div>
          {!integration.configured ? (
            <p className="text-sm leading-relaxed text-muted-foreground">
              A conexão está implementada. Falta configurar o acesso do painel e a conta de serviço
              do Google no ambiente do servidor. Consulte o guia de instalação entregue com o
              projeto.
            </p>
          ) : !integration.authenticated ? (
            <form onSubmit={login} className="space-y-3">
              <label className="block text-xs text-muted-foreground">
                Usuário
                <Input
                  name="username"
                  autoComplete="username"
                  value={user}
                  onChange={(e) => setUser(e.target.value)}
                  required
                  className="mt-1"
                />
              </label>
              <label className="block text-xs text-muted-foreground">
                Senha
                <Input
                  name="password"
                  autoComplete="current-password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="mt-1"
                />
              </label>
              <Button type="submit" disabled={submitting}>
                <LockKeyhole />
                {submitting ? "Entrando..." : "Entrar e sincronizar"}
              </Button>
            </form>
          ) : (
            <div className="flex flex-wrap gap-2">
              <Button onClick={() => void refresh()} disabled={loading}>
                <RefreshCw />
                {loading ? "Sincronizando..." : "Sincronizar agora"}
              </Button>
              <Button variant="outline" onClick={() => void logout()}>
                <LogOut />
                Sair
              </Button>
            </div>
          )}
          {(message || error) && (
            <p role="alert" className="mt-4 text-sm text-warning">
              {message || error}
            </p>
          )}
        </Panel>
        <Panel title="Regras de importação" description="Antes de calcular os indicadores">
          <div className="space-y-3">
            {[
              "Excluir linhas sem nome e contatos iniciados por test lead.",
              "Aplicar o período selecionado a todas as telas.",
              "Manter exemplos separados dos dados reais.",
              "Ler a planilha com permissão somente de leitura.",
              "Manter credenciais e autenticação no servidor.",
            ].map((rule) => (
              <div key={rule} className="flex items-start gap-3 text-sm">
                <Check className="mt-0.5 size-4 shrink-0 text-success" />
                <span className="text-muted-foreground">{rule}</span>
              </div>
            ))}
          </div>
        </Panel>
      </div>
      <ChangePassword />
      <Panel
        className="mt-5"
        title="Mapeamento dos leads"
        description="Cabeçalhos reconhecidos na sincronização"
      >
        <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
          {fields.map((field) => (
            <div
              key={field}
              className="flex items-center gap-2 rounded-md border border-border px-3 py-2.5 text-xs"
            >
              <Check className="size-3.5 shrink-0 text-primary" />
              {field}
            </div>
          ))}
        </div>
      </Panel>
    </>
  );
}
