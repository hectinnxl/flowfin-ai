import { Search } from "lucide-react";
import { useMemo, useState } from "react";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { leadStatuses } from "@/lib/dashboard-data";
import { dateKey, isOverdue } from "@/lib/dashboard-analytics";
import {
  DashboardControls,
  DemoNotice,
  EmptyState,
  PageHeader,
  Panel,
  formatCurrency,
} from "./dashboard-ui";
import { useDashboard } from "./dashboard-context";

export function LeadsPage() {
  const { leads, consultants, today } = useDashboard();
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("all");
  const [consultant, setConsultant] = useState("all");
  const [overdue, setOverdue] = useState("all");
  const filtered = useMemo(
    () =>
      leads.filter((lead) => {
        const text = `${lead.name} ${lead.phone} ${lead.email}`.toLowerCase();
        const late = isOverdue(lead, today);
        return (
          text.includes(search.toLowerCase()) &&
          (status === "all" || lead.status === status) &&
          (consultant === "all" || lead.consultant === consultant) &&
          (overdue === "all" || (overdue === "yes") === late)
        );
      }),
    [consultant, leads, overdue, search, status, today],
  );
  const exportRows = filtered.map((lead) => ({
    "Data de entrada": lead.entryDate,
    "Nome completo": lead.name,
    "WhatsApp/Telefone": lead.phone,
    Email: lead.email,
    "Tipo financiamento": lead.financingType,
    "Valor aproximado parcela": lead.installmentValue,
    Origem: lead.source,
    "Status atendimento": lead.status,
    Consultor: lead.consultant,
    Observações: lead.notes,
    "ID lead TikTok": lead.leadIdTikTok,
    "TikTok Lead ID": lead.tikTokLeadId,
    "TikTok Lead Status": lead.tikTokLeadStatus,
    "Último contato": lead.lastContact,
    "Próximo retorno": lead.nextReturn,
    "Valor contrato fechado": lead.closedContractValue,
    "Criativo/campanha": lead.creative,
  }));
  return (
    <>
      <PageHeader
        eyebrow="Operação comercial"
        title="Leads"
        description="Consulte contatos válidos, acompanhe cada etapa e identifique retornos que exigem atenção."
        actions={<DashboardControls exportRows={exportRows} exportName="soares-leads" />}
      />
      <DemoNotice />
      <div className="mb-5 grid gap-2 sm:grid-cols-2 xl:grid-cols-[minmax(220px,1fr)_180px_180px_170px]">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
            placeholder="Nome, telefone ou email"
          />
        </div>
        <Select value={status} onValueChange={setStatus}>
          <SelectTrigger>
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos os status</SelectItem>
            {leadStatuses.map((item) => (
              <SelectItem key={item} value={item}>
                {item}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={consultant} onValueChange={setConsultant}>
          <SelectTrigger>
            <SelectValue placeholder="Consultor" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos os consultores</SelectItem>
            <SelectItem value="Sem atribuição">Sem atribuição</SelectItem>
            {consultants.map((item) => (
              <SelectItem key={item.id} value={item.name}>
                {item.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={overdue} onValueChange={setOverdue}>
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos os retornos</SelectItem>
            <SelectItem value="yes">Retorno vencido</SelectItem>
            <SelectItem value="no">No prazo</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <Panel title="Base de leads" description={`${filtered.length} registro(s) carregado(s)`}>
        {!filtered.length ? (
          <EmptyState
            title="Nenhum lead encontrado"
            description="Os dados válidos aparecerão aqui após a integração. Linhas sem nome e nomes iniciados por “test lead” serão excluídos."
          />
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Entrada</TableHead>
                <TableHead>Nome</TableHead>
                <TableHead>Contato</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Consultor</TableHead>
                <TableHead>Próximo retorno</TableHead>
                <TableHead>Campanha</TableHead>
                <TableHead className="text-right">Contrato</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map((lead) => (
                <TableRow key={lead.id}>
                  <TableCell className="whitespace-nowrap text-muted-foreground">
                    {new Intl.DateTimeFormat("pt-BR").format(
                      new Date(`${dateKey(lead.entryDate)}T12:00:00`),
                    )}
                  </TableCell>
                  <TableCell>
                    <div className="min-w-40 font-medium">{lead.name}</div>
                    <div className="text-xs text-muted-foreground">{lead.email}</div>
                  </TableCell>
                  <TableCell className="whitespace-nowrap">{lead.phone}</TableCell>
                  <TableCell>
                    <Badge
                      variant="outline"
                      className="whitespace-nowrap border-primary/25 bg-primary/5 text-primary"
                    >
                      {lead.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="whitespace-nowrap">{lead.consultant}</TableCell>
                  <TableCell className="whitespace-nowrap">
                    {lead.nextReturn
                      ? new Intl.DateTimeFormat("pt-BR").format(
                          new Date(`${dateKey(lead.nextReturn)}T12:00:00`),
                        )
                      : "—"}
                  </TableCell>
                  <TableCell className="min-w-44">{lead.creative}</TableCell>
                  <TableCell className="text-right">
                    {formatCurrency(lead.closedContractValue)}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </Panel>
    </>
  );
}
