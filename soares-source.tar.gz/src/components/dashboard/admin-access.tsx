import { useEffect, useState, type FormEvent, type ReactNode } from "react";
import { LockKeyhole } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

type Session = { configured: boolean; authenticated: boolean; role: string | null };

export function AdminAccess({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function checkSession() {
    const response = await fetch("/api/dashboard/session", { cache: "no-store", credentials: "same-origin" });
    if (!response.ok) throw new Error("Não foi possível verificar o acesso. Tente novamente.");
    const data: Session = await response.json();
    setSession(data);
  }

  useEffect(() => {
    void checkSession().catch(() => setError("Não foi possível verificar o acesso. Atualize a página."));
    // Revalidate on focus and periodically so expired sessions hide the panel.
    const revalidate = () => void checkSession().catch(() => setSession(null));
    window.addEventListener("focus", revalidate);
    const timer = window.setInterval(revalidate, 60_000);
    return () => { window.removeEventListener("focus", revalidate); window.clearInterval(timer); };
  }, []);

  async function login(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError("");
    try {
      const response = await fetch("/api/dashboard/login", {
        method: "POST", credentials: "same-origin",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ user, password }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error ?? "Não foi possível entrar.");
      setPassword("");
      await checkSession();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Não foi possível entrar.");
    } finally { setBusy(false); }
  }

  if (session?.authenticated && session.role === "admin") return children;

  return (
    <main className="grid min-h-screen place-items-center bg-background px-5 text-foreground">
      <section className="w-full max-w-md rounded-xl border border-border bg-card p-8 shadow-xl">
        <div className="mb-6 flex items-center gap-3 text-primary">
          <LockKeyhole className="size-7" />
          <span className="font-display font-semibold tracking-widest">SOARES</span>
        </div>
        <h1 className="font-display text-2xl font-semibold">Acesso administrativo</h1>
        <p className="mt-2 text-sm text-muted-foreground">Painel exclusivo para administradores autorizados.</p>
        {!session ? <p role="status" className="mt-6 text-sm">Verificando acesso…</p> : !session.configured ? (
          <p role="status" className="mt-6 rounded-md border border-border p-4 text-sm text-muted-foreground">
            Acesso bloqueado. O primeiro administrador precisa ser configurado no servidor. Não há cadastro público.
          </p>
        ) : (
          <form onSubmit={login} className="mt-6 space-y-4">
            <label className="block text-sm">E-mail ou usuário
              <Input name="username" autoComplete="username" value={user} onChange={(e) => setUser(e.target.value)} required maxLength={254} className="mt-2" />
            </label>
            <label className="block text-sm">Senha
              <Input name="password" type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} required maxLength={256} className="mt-2" />
            </label>
            <Button type="submit" disabled={busy} className="w-full">{busy ? "Entrando…" : "Entrar no painel"}</Button>
          </form>
        )}
        {error && <p role="alert" className="mt-4 text-sm text-warning">{error}</p>}
      </section>
    </main>
  );
}
