import { useState, type FormEvent } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Panel } from "./dashboard-ui";

export function ChangePassword() {
  const [currentPassword, setCurrent] = useState("");
  const [newPassword, setNew] = useState("");
  const [confirmation, setConfirmation] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);
  async function submit(event: FormEvent) {
    event.preventDefault(); setError("");
    if (newPassword !== confirmation) { setError("As novas senhas não correspondem."); return; }
    setBusy(true);
    try {
      const response = await fetch("/api/dashboard/password", {
        method: "POST", credentials: "same-origin", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ currentPassword, newPassword, confirmation }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error ?? "Não foi possível alterar a senha.");
      setCurrent(""); setNew(""); setConfirmation(""); setDone(true);
    } catch (err) { setError(err instanceof Error ? err.message : "Não foi possível alterar a senha."); }
    finally { setBusy(false); }
  }
  return <Panel className="mt-5" title="Alterar senha" description="Confirme sua senha atual. Todas as sessões serão encerradas após a alteração.">
    {done ? <div role="status" className="space-y-3"><p>Senha alterada. Entre novamente com sua nova senha.</p><Button onClick={() => window.location.reload()}>Voltar ao login</Button></div> :
      <form onSubmit={submit} className="max-w-md space-y-4">
        <label className="block text-sm">Senha atual<Input className="mt-1" type="password" autoComplete="current-password" required maxLength={256} value={currentPassword} onChange={(e) => setCurrent(e.target.value)} /></label>
        <label className="block text-sm">Nova senha<Input className="mt-1" type="password" autoComplete="new-password" required minLength={12} maxLength={256} value={newPassword} onChange={(e) => setNew(e.target.value)} /></label>
        <label className="block text-sm">Confirmar nova senha<Input className="mt-1" type="password" autoComplete="new-password" required minLength={12} maxLength={256} value={confirmation} onChange={(e) => setConfirmation(e.target.value)} /></label>
        <p className="text-xs text-muted-foreground">Use pelo menos 12 caracteres e uma senha exclusiva para este painel.</p>
        {error && <p role="alert" className="text-sm text-warning">{error}</p>}
        <Button disabled={busy} type="submit">{busy ? "Salvando…" : "Salvar nova senha"}</Button>
      </form>}
  </Panel>;
}
