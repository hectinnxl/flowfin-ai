import { createHmac, randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import { JWT } from "google-auth-library";
import { mapSheetLeads, mapSheetSpend } from "./sheets-mapping";
import { loadAdmin, saveAdmin, type AdminCredentials } from "./admin-store.server";

const cookieName = "soares_session";
const attempts = { count: 0, resetAt: 0 };
const authConfigured = () =>
  Boolean(
    process.env["DASHBOARD_USER"] &&
    process.env["DASHBOARD_PASSWORD_HASH"] &&
    (process.env["DASHBOARD_SESSION_SECRET"]?.length ?? 0) >= 32,
  );
const sheetsConfigured = () =>
  Boolean(
    process.env["GOOGLE_SERVICE_ACCOUNT_EMAIL"] &&
    process.env["GOOGLE_PRIVATE_KEY"] &&
    process.env["GOOGLE_SHEET_ID"] &&
    process.env["GOOGLE_LEADS_RANGE"],
  );
const json = (body: unknown, status = 200, extra: Record<string, string> = {}) =>
  new Response(JSON.stringify(body), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "private, no-store",
      "x-content-type-options": "nosniff",
      ...extra,
    },
  });
function digest(text: string) {
  return createHmac("sha256", process.env["DASHBOARD_SESSION_SECRET"] ?? "")
    .update(text)
    .digest();
}
export function createSession(version = "initial") {
  const payload = Buffer.from(
    JSON.stringify({
      exp: Date.now() + 8 * 60 * 60 * 1000,
      nonce: randomBytes(16).toString("hex"),
      user: process.env["DASHBOARD_USER"],
      role: "admin",
      version,
    }),
  ).toString("base64url");
  return payload + "." + digest(payload).toString("base64url");
}
export function validSession(request: Request, version = "initial") {
  if (!authConfigured()) return false;
  const cookie = request.headers
    .get("cookie")
    ?.split(";")
    .map((c) => c.trim())
    .find((c) => c.startsWith(cookieName + "="))
    ?.slice(cookieName.length + 1);
  if (!cookie) return false;
  try {
    const [payload, signature] = cookie.split(".");
    if (!payload || !signature) return false;
    const expected = digest(payload),
      received = Buffer.from(signature, "base64url");
    const claims = JSON.parse(Buffer.from(payload, "base64url").toString());
    return (
      expected.length === received.length &&
      timingSafeEqual(expected, received) &&
      Number(claims.exp) > Date.now() &&
      claims.user === process.env["DASHBOARD_USER"] &&
      claims.role === "admin" && claims.version === version
    );
  } catch {
    return false;
  }
}
function cookieHeader(request: Request, value: string, age: number) {
  const secure = new URL(request.url).protocol === "https:";
  return `${cookieName}=${value}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${age}${secure ? "; Secure" : ""}`;
}
function sameOrigin(request: Request) {
  return request.headers.get("origin") === new URL(request.url).origin;
}
function passwordMatches(password: string, storedHash = process.env["DASHBOARD_PASSWORD_HASH"] ?? "") {
  const [scheme, salt, hash] = storedHash.split(":");
  if (scheme !== "scrypt" || !salt || !hash || password.length > 256) return false;
  const expected = Buffer.from(hash, "hex"),
    received = scryptSync(password, salt, 64);
  return expected.length === received.length && timingSafeEqual(expected, received);
}

async function sheetValues(client: JWT, range: string) {
  const id = process.env["GOOGLE_SHEET_ID"]!;
  const url = `https://sheets.googleapis.com/v4/spreadsheets/${encodeURIComponent(id)}/values/${encodeURIComponent(range)}?valueRenderOption=FORMATTED_VALUE`;
  const response = await client.request<{ values?: unknown[][] }>({
    url,
    method: "GET",
    timeout: 15000,
  });
  return response.data.values ?? [];
}

export async function handleDashboardApi(request: Request): Promise<Response | null> {
  const pathname = new URL(request.url).pathname;
  if (!pathname.startsWith("/api/dashboard")) return null;
  let snapshot;
  try { snapshot = await loadAdmin(); }
  catch { return json({ error: "Acesso temporariamente indisponível. Tente novamente." }, 503); }
  const credentials: AdminCredentials = snapshot.credentials;
  if (pathname === "/api/dashboard/session" && request.method === "GET") {
    const authenticated = validSession(request, credentials.version);
    return json({ configured: authConfigured(), authenticated, role: authenticated ? "admin" : null });
  }
  if (pathname === "/api/dashboard/login" && request.method === "POST") {
    if (!sameOrigin(request)) return json({ error: "Origem inválida." }, 403);
    if (!authConfigured())
      return json({ error: "O acesso ainda não foi configurado no servidor." }, 503);
    if (Date.now() > attempts.resetAt) {
      attempts.count = 0;
      attempts.resetAt = Date.now() + 15 * 60 * 1000;
    }
    if (attempts.count >= 5) return json({ error: "Muitas tentativas. Aguarde 15 minutos." }, 429);
    attempts.count++;
    let data: { user?: unknown; password?: unknown };
    try {
      data = await request.json();
    } catch {
      return json({ error: "Dados inválidos." }, 400);
    }
    const passwordOk = typeof data.password === "string" && passwordMatches(data.password, credentials.passwordHash);
    if (data.user !== process.env["DASHBOARD_USER"] || !passwordOk)
      return json({ error: "Usuário ou senha inválidos." }, 401);
    attempts.count = 0;
    return json({ ok: true }, 200, {
      "set-cookie": cookieHeader(request, createSession(credentials.version), 8 * 60 * 60),
    });
  }
  if (pathname === "/api/dashboard/logout" && request.method === "POST") {
    if (!sameOrigin(request)) return json({ error: "Origem inválida." }, 403);
    return json({ ok: true }, 200, { "set-cookie": cookieHeader(request, "", 0) });
  }
  if (pathname === "/api/dashboard/password" && request.method === "POST") {
    if (!sameOrigin(request)) return json({ error: "Origem inválida." }, 403);
    if (!validSession(request, credentials.version)) return json({ error: "Entre novamente para alterar a senha." }, 401);
    if (Date.now() > attempts.resetAt) {
      attempts.count = 0;
      attempts.resetAt = Date.now() + 15 * 60 * 1000;
    }
    if (attempts.count >= 5) return json({ error: "Muitas tentativas. Aguarde 15 minutos." }, 429);
    let data: { currentPassword?: unknown; newPassword?: unknown; confirmation?: unknown };
    try { data = await request.json(); }
    catch { return json({ error: "Dados inválidos." }, 400); }
    attempts.count++;
    if (typeof data.currentPassword !== "string" || !passwordMatches(data.currentPassword, credentials.passwordHash))
      return json({ error: "Senha atual incorreta." }, 401);
    if (typeof data.newPassword !== "string" || data.newPassword.length < 12 || data.newPassword.length > 256)
      return json({ error: "Use uma nova senha entre 12 e 256 caracteres." }, 400);
    if (data.newPassword !== data.confirmation) return json({ error: "A confirmação não corresponde à nova senha." }, 400);
    if (data.newPassword === data.currentPassword) return json({ error: "Escolha uma senha diferente da atual." }, 400);
    const salt = randomBytes(16).toString("hex");
    const updated: AdminCredentials = {
      passwordHash: "scrypt:" + salt + ":" + scryptSync(data.newPassword, salt, 64).toString("hex"),
      version: randomBytes(24).toString("hex"),
    };
    try { await saveAdmin(updated, snapshot); }
    catch { return json({ error: "Não foi possível salvar a nova senha. Ela não foi confirmada; tente novamente." }, 503); }
    attempts.count = 0;
    return json({ ok: true }, 200, { "set-cookie": cookieHeader(request, "", 0) });
  }
  if (pathname !== "/api/dashboard" || request.method !== "GET")
    return json({ error: "Rota não encontrada." }, 404);
  const authenticated = validSession(request, credentials.version);
  const configured = authConfigured() && sheetsConfigured();
  const integration = {
    configured,
    authenticated,
    connected: false,
    updatedAt: null as string | null,
  };
  if (!configured || !authenticated) return json({ integration, leads: [], spend: [] });
  try {
    const client = new JWT({
      email: process.env["GOOGLE_SERVICE_ACCOUNT_EMAIL"]!,
      key: process.env["GOOGLE_PRIVATE_KEY"]!.replaceAll("\\n", "\n"),
      scopes: ["https://www.googleapis.com/auth/spreadsheets.readonly"],
    });
    const leads = mapSheetLeads(await sheetValues(client, process.env["GOOGLE_LEADS_RANGE"]!));
    const spendRange = process.env["GOOGLE_SPEND_RANGE"];
    const spend = spendRange ? mapSheetSpend(await sheetValues(client, spendRange)) : [];
    return json({
      integration: { ...integration, connected: true, updatedAt: new Date().toISOString() },
      leads,
      spend,
    });
  } catch {
    return json(
      {
        error:
          "Não foi possível ler a planilha. Confira as credenciais, os cabeçalhos e a permissão de leitura.",
      },
      502,
    );
  }
}
