import { campaignDefinitions, type Consultant, type Lead } from "./dashboard-data";
export type SpendEntry = { date: string; campaignId: string; amount: number };
export function todayInBrazil(now = new Date()) {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "America/Sao_Paulo",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(now);
}
export function dateKey(value: string): string {
  if (!value) return "";
  if (/^\d{4}-\d{2}-\d{2}$/.test(value)) return value;
  const brazilian = value.match(/^(\d{2})\/(\d{2})\/(\d{4})/);
  if (brazilian) return brazilian[3] + "-" + brazilian[2] + "-" + brazilian[1];
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? "" : todayInBrazil(parsed);
}
export function periodStart(period: string, today: string) {
  if (period === "year") return today.slice(0, 4) + "-01-01";
  const date = new Date(today + "T12:00:00Z");
  date.setUTCDate(date.getUTCDate() - ({ "7d": 6, "30d": 29, "90d": 89 }[period] ?? 29));
  return date.toISOString().slice(0, 10);
}
export function inPeriod(value: string, period: string, today: string) {
  const key = dateKey(value);
  return Boolean(key) && key >= periodStart(period, today) && key <= today;
}
export function summarizeConsultants(leads: Lead[]): Consultant[] {
  const result = new Map<string, Consultant>();
  for (const lead of leads) {
    const name = lead.consultant.trim();
    if (!name || name === "Sem atribuição") continue;
    const row = result.get(name) ?? {
      id: name,
      name,
      leads: 0,
      contacts: 0,
      proposals: 0,
      closed: 0,
      revenue: 0,
    };
    row.leads++;
    if (lead.lastContact) row.contacts++;
    if (["Proposta enviada", "Fechado"].includes(lead.status)) row.proposals++;
    if (lead.status === "Fechado") {
      row.closed++;
      row.revenue += lead.closedContractValue;
    }
    result.set(name, row);
  }
  return [...result.values()];
}
export function summarizeDaily(leads: Lead[]) {
  const result = new Map<string, { date: string; leads: number; revenue: number }>();
  for (const lead of leads) {
    const date = dateKey(lead.entryDate);
    if (!date) continue;
    const row = result.get(date) ?? { date, leads: 0, revenue: 0 };
    row.leads++;
    if (lead.status === "Fechado") row.revenue += lead.closedContractValue;
    result.set(date, row);
  }
  return [...result.values()].sort((a, b) => a.date.localeCompare(b.date));
}
export function campaignTotals(entries: SpendEntry[], period: string, today: string) {
  return Object.fromEntries(
    campaignDefinitions.map((c) => [
      c.id,
      entries
        .filter((e) => e.campaignId === c.id && inPeriod(e.date, period, today))
        .reduce((sum, e) => sum + e.amount, 0),
    ]),
  );
}
export function isOverdue(lead: Lead, today: string) {
  const date = dateKey(lead.nextReturn);
  return Boolean(date) && date < today && !["Fechado", "Perdido"].includes(lead.status);
}
export function csvText(rows: Record<string, unknown>[], columns: string[]) {
  const quote = (value: unknown) => {
    let text = String(value ?? "");
    if (typeof value === "string" && /^[\s]*[=+@-]/.test(text)) text = "'" + text;
    return '"' + text.replaceAll('"', '""') + '"';
  };
  return (
    "\ufeff" +
    [
      columns.map(quote).join(";"),
      ...rows.map((row) => columns.map((key) => quote(row[key])).join(";")),
    ].join("\r\n")
  );
}
