export const leadStatuses = [
  "Novo",
  "Em contato",
  "Análise solicitada",
  "Em análise",
  "Proposta enviada",
  "Fechado",
  "Perdido",
  "Sem resposta",
] as const;

export type LeadStatus = (typeof leadStatuses)[number];

export type Lead = {
  id: string;
  entryDate: string;
  name: string;
  phone: string;
  email: string;
  financingType: string;
  installmentValue: number;
  source: string;
  status: LeadStatus;
  consultant: string;
  notes: string;
  leadIdTikTok: string;
  tikTokLeadId: string;
  tikTokLeadStatus: string;
  lastContact: string;
  nextReturn: string;
  closedContractValue: number;
  creative: string;
};

export type Consultant = {
  id: string;
  name: string;
  leads: number;
  contacts: number;
  proposals: number;
  closed: number;
  revenue: number;
};

export const campaignDefinitions = [
  { id: "creative-01", name: "Criativo 01 – Veículo", category: "Financiamento de veículo", dailyBudget: 50 },
  { id: "creative-02", name: "Criativo 02 – Contrato", category: "Crédito com contrato", dailyBudget: 50 },
] as const;

export const demoLeads: Lead[] = [
  { id: "demo-1", entryDate: "2026-09-28", name: "Marina Costa", phone: "(11) 99999-1010", email: "marina@exemplo.com", financingType: "Veículo", installmentValue: 1480, source: "TikTok", status: "Em análise", consultant: "Ana Souza", notes: "Documentação recebida", leadIdTikTok: "DEMO-TT-01", tikTokLeadId: "DEMO-1001", tikTokLeadStatus: "qualified", lastContact: "2026-10-02", nextReturn: "2026-10-04", closedContractValue: 0, creative: "Criativo 01 – Veículo" },
  { id: "demo-2", entryDate: "2026-09-29", name: "Carlos Almeida", phone: "(21) 98888-2020", email: "carlos@exemplo.com", financingType: "Contrato", installmentValue: 920, source: "TikTok", status: "Proposta enviada", consultant: "Bruno Lima", notes: "Aguardando retorno", leadIdTikTok: "DEMO-TT-02", tikTokLeadId: "DEMO-1002", tikTokLeadStatus: "contacted", lastContact: "2026-10-01", nextReturn: "2026-10-03", closedContractValue: 0, creative: "Criativo 02 – Contrato" },
  { id: "demo-3", entryDate: "2026-09-30", name: "Luciana Ribeiro", phone: "(31) 97777-3030", email: "luciana@exemplo.com", financingType: "Veículo", installmentValue: 2150, source: "TikTok", status: "Fechado", consultant: "Ana Souza", notes: "Exemplo demonstrativo", leadIdTikTok: "DEMO-TT-03", tikTokLeadId: "DEMO-1003", tikTokLeadStatus: "converted", lastContact: "2026-10-02", nextReturn: "", closedContractValue: 46500, creative: "Criativo 01 – Veículo" },
  { id: "demo-4", entryDate: "2026-10-01", name: "Rafael Mendes", phone: "(41) 96666-4040", email: "rafael@exemplo.com", financingType: "Contrato", installmentValue: 1180, source: "TikTok", status: "Em contato", consultant: "Bruno Lima", notes: "Primeiro contato realizado", leadIdTikTok: "DEMO-TT-04", tikTokLeadId: "DEMO-1004", tikTokLeadStatus: "contacted", lastContact: "2026-10-02", nextReturn: "2026-10-05", closedContractValue: 0, creative: "Criativo 02 – Contrato" },
  { id: "demo-5", entryDate: "2026-10-02", name: "Beatriz Nunes", phone: "(51) 95555-5050", email: "beatriz@exemplo.com", financingType: "Veículo", installmentValue: 1740, source: "TikTok", status: "Novo", consultant: "Sem atribuição", notes: "Aguardando triagem", leadIdTikTok: "DEMO-TT-05", tikTokLeadId: "DEMO-1005", tikTokLeadStatus: "new", lastContact: "", nextReturn: "", closedContractValue: 0, creative: "Criativo 01 – Veículo" },
];

export const demoConsultants: Consultant[] = [
  { id: "c1", name: "Ana Souza", leads: 2, contacts: 2, proposals: 1, closed: 1, revenue: 46500 },
  { id: "c2", name: "Bruno Lima", leads: 2, contacts: 2, proposals: 1, closed: 0, revenue: 0 },
];

export const demoDaily = [
  { date: "28 set", leads: 1, revenue: 0 },
  { date: "29 set", leads: 1, revenue: 0 },
  { date: "30 set", leads: 1, revenue: 46500 },
  { date: "01 out", leads: 1, revenue: 0 },
  { date: "02 out", leads: 1, revenue: 0 },
];

export function sanitizeLeads(leads: Lead[]) {
  return leads.filter((lead) => lead.name.trim() && !lead.name.trim().toLowerCase().startsWith("test lead"));
}

