import {
  campaignDefinitions,
  leadStatuses,
  sanitizeLeads,
  type Lead,
  type LeadStatus,
} from "./dashboard-data";
import { dateKey, type SpendEntry } from "./dashboard-analytics";

const normalize = (value: unknown) =>
  String(value ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]/g, "");
export function money(value: unknown) {
  if (typeof value === "number") return Number.isFinite(value) ? Math.max(0, value) : 0;
  let text = String(value ?? "").replace(/[^\d.,-]/g, "");
  if (text.includes(",")) text = text.replaceAll(".", "").replace(",", ".");
  const amount = Number(text);
  return Number.isFinite(amount) ? Math.max(0, amount) : 0;
}
function rows(values: unknown[][]) {
  const headers = (values[0] ?? []).map(normalize);
  return values.slice(1).map((row, index) => ({
    index,
    get: (...names: string[]) => {
      const col = headers.findIndex((header) => names.some((name) => normalize(name) === header));
      return col < 0 ? "" : (row[col] ?? "");
    },
  }));
}
export function mapSheetLeads(values: unknown[][]): Lead[] {
  const headers = (values[0] ?? []).map(normalize);
  if (!headers.includes(normalize("Nome completo")) && !headers.includes(normalize("Nome")))
    throw new Error("A aba de leads precisa do cabeçalho Nome completo.");
  return sanitizeLeads(
    rows(values).map(({ get, index }) => {
      const text = (...keys: string[]) => String(get(...keys)).trim();
      const rawStatus = text("Status do atendimento", "Status atendimento", "Status");
      const status = leadStatuses.find((s) => normalize(s) === normalize(rawStatus)) ?? "Novo";
      const rawCreative = text("Criativo/campanha", "Criativo", "Campanha");
      const creative =
        campaignDefinitions.find((c) => normalize(c.name) === normalize(rawCreative))?.name ??
        rawCreative;
      return {
        id: text("ID do lead TikTok", "ID lead TikTok", "TikTok Lead ID") || `sheet-${index + 2}`,
        entryDate: dateKey(text("Data de entrada", "Data")),
        name: text("Nome completo", "Nome"),
        phone: text("WhatsApp/Telefone", "WhatsApp", "Telefone"),
        email: text("Email", "E-mail"),
        financingType: text("Tipo de financiamento", "Tipo financiamento"),
        installmentValue: money(get("Valor aproximado da parcela", "Valor aproximado parcela")),
        source: text("Origem"),
        status: status as LeadStatus,
        consultant: text("Consultor responsável", "Consultor") || "Sem atribuição",
        notes: text("Observações"),
        leadIdTikTok: text("ID do lead TikTok", "ID lead TikTok"),
        tikTokLeadId: text("TikTok Lead ID"),
        tikTokLeadStatus: text("TikTok Lead Status"),
        lastContact: dateKey(text("Último contato")),
        nextReturn: dateKey(text("Próximo retorno")),
        closedContractValue: money(get("Valor do contrato fechado", "Valor contrato fechado")),
        creative,
      };
    }),
  );
}
export function mapSheetSpend(values: unknown[][]): SpendEntry[] {
  const headers = (values[0] ?? []).map(normalize);
  if (
    !headers.includes(normalize("Data")) ||
    !["Gasto efetivo", "Gasto efetivo (R$)"].some((h) => headers.includes(normalize(h))) ||
    !["Criativo/campanha", "Campanha / criativo"].some((h) => headers.includes(normalize(h)))
  )
    throw new Error("A aba de gastos deve conter Data, Campanha / criativo e Gasto efetivo (R$).");
  return rows(values).flatMap(({ get }) => {
    const creative = normalize(get("Campanha / criativo", "Criativo/campanha"));
    const campaign = campaignDefinitions.find(
      (c) => normalize(c.name) === creative || normalize(c.id) === creative,
    );
    const date = dateKey(String(get("Data")));
    return campaign && date
      ? [
          {
            date,
            campaignId: campaign.id,
            amount: money(get("Gasto efetivo (R$)", "Gasto efetivo")),
          },
        ]
      : [];
  });
}
