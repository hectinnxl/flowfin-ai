// @vitest-environment node
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { scryptSync } from "node:crypto";
import { createSession, handleDashboardApi, validSession } from "@/lib/dashboard-api.server";

const storage = vi.hoisted(() => ({ getWithMetadata: vi.fn(), setJSON: vi.fn(), get: vi.fn() }));
vi.mock("@netlify/blobs", () => ({ getStore: () => storage }));
const original = "Original-test-password!";
const next = "New-exclusive-password!";
let record: { passwordHash: string; version: string } | null;

beforeEach(() => {
  record = null;
  vi.stubEnv("NETLIFY", "true");
  vi.stubEnv("DASHBOARD_USER", "test-admin");
  vi.stubEnv("DASHBOARD_SESSION_SECRET", "server-only-secret-32-characters-test-value");
  vi.stubEnv("DASHBOARD_PASSWORD_HASH", "scrypt:test-salt:" + scryptSync(original, "test-salt", 64).toString("hex"));
  storage.getWithMetadata.mockImplementation(async () => record ? { data: record, etag: "revision" } : null);
  storage.setJSON.mockImplementation(async (_key, data) => { record = data; return { modified: true }; });
  storage.get.mockImplementation(async () => record);
});
afterEach(() => { vi.unstubAllEnvs(); vi.resetAllMocks(); });

function change(body: unknown, cookie = createSession(), origin = "https://example.test") {
  return handleDashboardApi(new Request("https://example.test/api/dashboard/password", {
    method: "POST", headers: { origin, cookie: "soares_session=" + cookie, "Content-Type": "application/json" },
    body: JSON.stringify(body),
  }));
}
describe("Troca segura de senha", () => {
  it("exige sessão e mesma origem", async () => {
    expect((await change({}, "invalid"))!.status).toBe(401);
    expect((await change({}, createSession(), "https://other.test"))!.status).toBe(403);
    expect(storage.setJSON).not.toHaveBeenCalled();
  });
  it("exige senha atual, tamanho mínimo e confirmação", async () => {
    expect((await change({ currentPassword: "wrong", newPassword: next, confirmation: next }))!.status).toBe(401);
    expect((await change({ currentPassword: original, newPassword: "short", confirmation: "short" }))!.status).toBe(400);
    expect((await change({ currentPassword: original, newPassword: next, confirmation: "mismatch" }))!.status).toBe(400);
    expect(storage.setJSON).not.toHaveBeenCalled();
  });
  it("persiste só o hash, invalida a sessão antiga e aceita apenas a senha nova", async () => {
    const oldSession = createSession();
    const response = await change({ currentPassword: original, newPassword: next, confirmation: next }, oldSession);
    expect(response!.status).toBe(200);
    expect(response!.headers.get("set-cookie")).toContain("Max-Age=0");
    expect(record!.passwordHash).toMatch(/^scrypt:/);
    expect(JSON.stringify(record)).not.toContain(next);
    expect(validSession(new Request("https://example.test", { headers: { cookie: "soares_session=" + oldSession } }), record!.version)).toBe(false);
    const request = (password: string) => new Request("https://example.test/api/dashboard/login", {
      method: "POST", headers: { origin: "https://example.test" }, body: JSON.stringify({ user: "test-admin", password }),
    });
    expect((await handleDashboardApi(request(original)))!.status).toBe(401);
    expect((await handleDashboardApi(request(next)))!.status).toBe(200);
  });
  it("não confirma sucesso se a gravação falhar", async () => {
    storage.setJSON.mockRejectedValue(new Error("Storage unavailable"));
    const response = await change({ currentPassword: original, newPassword: next, confirmation: next });
    expect(response!.status).toBe(503);
    expect(response!.headers.get("set-cookie")).toBeNull();
  });
  it("falha fechada se não puder ler o estado da senha", async () => {
    storage.getWithMetadata.mockRejectedValue(new Error("Storage unavailable"));
    const response = await handleDashboardApi(new Request("https://example.test/api/dashboard/session"));
    expect(response!.status).toBe(503);
  });
});
