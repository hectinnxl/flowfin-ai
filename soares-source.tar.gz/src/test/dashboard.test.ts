import { describe, expect, it } from "vitest";
import { demoLeads, sanitizeLeads } from "@/lib/dashboard-data";
import {
  campaignTotals,
  csvText,
  inPeriod,
  isOverdue,
  summarizeConsultants,
  summarizeDaily,
  todayInBrazil,
} from "@/lib/dashboard-analytics";
import { mapSheetLeads, mapSheetSpend, money } from "@/lib/sheets-mapping";

describe("Indicadores", () => {
  it("exclui testes e linhas sem nome", () => {
    const lead = demoLeads[0]!;
    expect(
      sanitizeLeads([lead, { ...lead, name: " Test Lead 123" }, { ...lead, name: " " }]),
    ).toEqual([lead]);
  });
  it("aplica limites inclusivos e exclui datas futuras", () => {
    expect(inPeriod("2026-09-26", "7d", "2026-10-02")).toBe(true);
    expect(inPeriod("2026-09-25", "7d", "2026-10-02")).toBe(false);
    expect(inPeriod("2026-10-03", "30d", "2026-10-02")).toBe(false);
    expect(inPeriod("", "year", "2026-10-02")).toBe(false);
    expect(todayInBrazil(new Date("2026-10-03T01:00:00Z"))).toBe("2026-10-02");
  });
  it("soma apenas gastos do criativo no período", () => {
    const totals = campaignTotals(
      [
        { date: "2026-10-02", campaignId: "creative-01", amount: 50 },
        { date: "2026-08-01", campaignId: "creative-01", amount: 999 },
        { date: "2026-10-01", campaignId: "creative-02", amount: 20 },
      ],
      "7d",
      "2026-10-02",
    );
    expect(totals).toEqual({ "creative-01": 50, "creative-02": 20 });
  });
  it("deriva ranking e gráfico dos mesmos leads", () => {
    const consultants = summarizeConsultants(demoLeads);
    expect(consultants.reduce((sum, c) => sum + c.closed, 0)).toBe(1);
    expect(summarizeDaily(demoLeads).reduce((sum, row) => sum + row.revenue, 0)).toBe(46500);
  });
  it("retornos concluídos não ficam vencidos", () => {
    const lead = { ...demoLeads[0]!, nextReturn: "2026-10-01" };
    expect(isOverdue(lead, "2026-10-02")).toBe(true);
    expect(isOverdue({ ...lead, status: "Fechado" }, "2026-10-02")).toBe(false);
  });
});
describe("Importação e exportação", () => {
  it("aceita os cabeçalhos verificados da planilha SOARES", () => {
    const leads = mapSheetLeads([
      [
        "Nome completo",
        "Status do atendimento",
        "Consultor responsável",
        "Tipo de financiamento",
        "Valor aproximado da parcela",
        "ID do lead TikTok",
        "Valor do contrato fechado",
      ],
      ["Cliente", "Fechado", "Gabriel", "Veículo", "900,00", "tt-123", "30.000,00"],
    ]);
    expect(leads[0]).toMatchObject({
      status: "Fechado",
      consultant: "Gabriel",
      financingType: "Veículo",
      installmentValue: 900,
      leadIdTikTok: "tt-123",
      closedContractValue: 30000,
    });
    expect(
      mapSheetSpend([
        ["Data", "Campanha / criativo", "Gasto efetivo (R$)"],
        ["02/10/2026", "Criativo 02 – Contrato", "75,90"],
      ]),
    ).toEqual([{ date: "2026-10-02", campaignId: "creative-02", amount: 75.9 }]);
  });
  it("converte valores BR e mapeia nomes por cabeçalho", () => {
    expect(money("R$ 1.234,56")).toBe(1234.56);
    expect(money("inválido")).toBe(0);
    const leads = mapSheetLeads([
      ["Status atendimento", "Nome completo", "Data de entrada", "Valor contrato fechado"],
      ["Fechado", "Pessoa", "02/10/2026 10:00", "R$ 1.234,56"],
      ["Novo", "test lead 1", "02/10/2026", "0"],
    ]);
    expect(leads).toHaveLength(1);
    expect(leads[0]).toMatchObject({
      name: "Pessoa",
      status: "Fechado",
      entryDate: "2026-10-02",
      closedContractValue: 1234.56,
    });
  });
  it("valida o cabeçalho da fonte", () => {
    expect(() => mapSheetLeads([["coluna desconhecida"]])).toThrow();
    expect(
      mapSheetSpend([
        ["Data", "Criativo/campanha", "Gasto efetivo"],
        ["02/10/2026", "Criativo 01 – Veículo", "50,00"],
      ]),
    ).toEqual([{ date: "2026-10-02", campaignId: "creative-01", amount: 50 }]);
  });
  it("mantém cabeçalhos vazios e neutraliza fórmulas em CSV", () => {
    expect(csvText([], ["Nome", "Status"])).toBe('\ufeff"Nome";"Status"');
    expect(csvText([{ Nome: "=HYPERLINK(1)", Status: 'A"B' }], ["Nome", "Status"])).toContain(
      '"\'=HYPERLINK(1)";"A""B"',
    );
  });
});
