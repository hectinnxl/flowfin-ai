// @vitest-environment node
import { afterEach, describe, expect, it, vi } from "vitest";
import { randomBytes, scryptSync } from "node:crypto";
import { createSession, handleDashboardApi, validSession } from "@/lib/dashboard-api.server";

const { googleRequest } = vi.hoisted(() => ({ googleRequest: vi.fn() }));
vi.mock("google-auth-library", () => ({
  JWT: class {
    request = googleRequest;
  },
}));

afterEach(() => {
  vi.unstubAllEnvs();
  vi.clearAllMocks();
});
function configure() {
  const salt = randomBytes(16).toString("hex");
  vi.stubEnv("DASHBOARD_USER", "test-user");
  vi.stubEnv(
    "DASHBOARD_PASSWORD_HASH",
    "scrypt:" + salt + ":" + scryptSync("test-password-123", salt, 64).toString("hex"),
  );
  vi.stubEnv("DASHBOARD_SESSION_SECRET", randomBytes(48).toString("hex"));
}
describe("Acesso real ao painel", () => {
  it("bloqueia acesso quando o administrador não foi configurado", async () => {
    vi.stubEnv("DASHBOARD_USER", "");
    const response = await handleDashboardApi(new Request("https://example.test/api/dashboard/session"));
    expect(await response!.json()).toEqual({ configured: false, authenticated: false, role: null });
  });
  it("só reconhece sessões do administrador atualmente autorizado", async () => {
    configure();
    const request = new Request("https://example.test/api/dashboard/session", {
      headers: { cookie: "soares_session=" + createSession() },
    });
    expect(await (await handleDashboardApi(request))!.json()).toMatchObject({ authenticated: true, role: "admin" });
    vi.stubEnv("DASHBOARD_USER", "outro-admin");
    expect(validSession(request)).toBe(false);
  });
  it("sincroniza leads e gastos somente após autenticação", async () => {
    configure();
    vi.stubEnv("GOOGLE_SERVICE_ACCOUNT_EMAIL", "service@example.test");
    vi.stubEnv("GOOGLE_PRIVATE_KEY", "mock-key");
    vi.stubEnv("GOOGLE_SHEET_ID", "test-sheet");
    vi.stubEnv("GOOGLE_LEADS_RANGE", "'Leads TikTok'!A:Q");
    vi.stubEnv("GOOGLE_SPEND_RANGE", "'Investimento Ads'!A4:E");
    googleRequest.mockResolvedValueOnce({
      data: {
        values: [
          ["Nome completo", "Data de entrada", "Status do atendimento"],
          ["Cliente teste interno", "02/10/2026", "Novo"],
        ],
      },
    });
    googleRequest.mockResolvedValueOnce({
      data: {
        values: [
          ["Data", "Campanha / criativo", "Gasto efetivo (R$)"],
          ["02/10/2026", "Criativo 01 – Veículo", "50,00"],
        ],
      },
    });
    const response = await handleDashboardApi(
      new Request("http://localhost/api/dashboard", {
        headers: { cookie: "soares_session=" + createSession() },
      }),
    );
    const data = await response!.json();
    expect(data.integration.connected).toBe(true);
    expect(data.leads).toHaveLength(1);
    expect(data.spend[0].amount).toBe(50);
    expect(googleRequest).toHaveBeenCalledTimes(2);
    expect(response!.headers.get("cache-control")).toBe("private, no-store");
  });
  it("não envia dados sem sessão", async () => {
    configure();
    const response = await handleDashboardApi(new Request("http://localhost/api/dashboard"));
    expect(await response!.json()).toMatchObject({
      leads: [],
      spend: [],
      integration: { authenticated: false, connected: false },
    });
  });
  it("assina sessão e rejeita adulteração", () => {
    configure();
    const session = createSession();
    expect(
      validSession(
        new Request("https://example.test/", { headers: { cookie: "soares_session=" + session } }),
      ),
    ).toBe(true);
    expect(
      validSession(
        new Request("https://example.test/", { headers: { cookie: "soares_session=x" + session } }),
      ),
    ).toBe(false);
  });
  it("rejeita login de outra origem", async () => {
    configure();
    const response = await handleDashboardApi(
      new Request("https://example.test/api/dashboard/login", {
        method: "POST",
        headers: { Origin: "https://evil.test" },
        body: "{}",
      }),
    );
    expect(response!.status).toBe(403);
  });
  it("valida senha e emite cookie HttpOnly", async () => {
    configure();
    const response = await handleDashboardApi(
      new Request("https://example.test/api/dashboard/login", {
        method: "POST",
        headers: { Origin: "https://example.test", "Content-Type": "application/json" },
        body: JSON.stringify({ user: "test-user", password: "test-password-123" }),
      }),
    );
    expect(response!.status).toBe(200);
    expect(response!.headers.get("set-cookie")).toContain("HttpOnly; SameSite=Strict");
    expect(response!.headers.get("set-cookie")).toContain("Secure");
  });
});
