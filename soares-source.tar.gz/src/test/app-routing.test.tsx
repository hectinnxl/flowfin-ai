import { QueryClient } from "@tanstack/react-query";
import { createMemoryHistory, createRouter } from "@tanstack/react-router";
import { describe, expect, it } from "vitest";
import { routeTree } from "@/routeTree.gen";

describe("Rotas do painel", () => {
  it.each(["/", "/consultores", "/leads", "/campanhas", "/financeiro", "/configuracoes"])(
    "resolve %s",
    async (path) => {
      const router = createRouter({
        routeTree,
        context: { queryClient: new QueryClient() },
        history: createMemoryHistory({ initialEntries: [path] }),
      });
      await router.load();
      expect(router.state.matches.at(-1)?.pathname).toBe(path);
      expect(router.state.matches.every((match) => match.status === "success")).toBe(true);
    },
  );
});
