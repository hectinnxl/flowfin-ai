import { createFileRoute } from "@tanstack/react-router";
import { OverviewPage } from "@/components/dashboard/overview";
export const Route=createFileRoute("/")({head:()=>({meta:[{title:"Visão Geral — SOARES Revenue Analytics"},{name:"description",content:"Visão geral de leads, conversões e receita da SOARES Soluções Financeiras."},{property:"og:title",content:"Visão Geral — SOARES Revenue Analytics"},{property:"og:description",content:"Acompanhamento executivo da operação comercial SOARES."},{property:"og:type",content:"website"},{name:"twitter:card",content:"summary_large_image"}]}),component:OverviewPage});

