import { createFileRoute } from "@tanstack/react-router"; import { FinancePage } from "@/components/dashboard/finance";
export const Route=createFileRoute("/financeiro")({head:()=>({meta:[{title:"Financeiro — SOARES Revenue Analytics"},{name:"description",content:"Receita, custos e resultado comercial."},{property:"og:title",content:"Financeiro — SOARES Revenue Analytics"},{property:"og:description",content:"Visão financeira consolidada da operação."},{property:"og:type",content:"website"},{name:"twitter:card",content:"summary_large_image"}]}),component:FinancePage});

