import { createFileRoute } from "@tanstack/react-router"; import { ConsultantsPage } from "@/components/dashboard/consultants";
export const Route=createFileRoute("/consultores")({head:()=>({meta:[{title:"Consultores — SOARES Revenue Analytics"},{name:"description",content:"Performance comercial por consultor."},{property:"og:title",content:"Consultores — SOARES Revenue Analytics"},{property:"og:description",content:"Acompanhe a performance da equipe comercial."},{property:"og:type",content:"website"},{name:"twitter:card",content:"summary_large_image"}]}),component:ConsultantsPage});

