import { createFileRoute } from "@tanstack/react-router"; import { LeadsPage } from "@/components/dashboard/leads";
export const Route=createFileRoute("/leads")({head:()=>({meta:[{title:"Leads — SOARES Revenue Analytics"},{name:"description",content:"Gestão e acompanhamento de leads comerciais."},{property:"og:title",content:"Leads — SOARES Revenue Analytics"},{property:"og:description",content:"Consulte e filtre os leads da operação SOARES."},{property:"og:type",content:"website"},{name:"twitter:card",content:"summary_large_image"}]}),component:LeadsPage});

