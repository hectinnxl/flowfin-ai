import { createFileRoute } from "@tanstack/react-router"; import { CampaignsPage } from "@/components/dashboard/campaigns";
export const Route=createFileRoute("/campanhas")({head:()=>({meta:[{title:"Campanhas — SOARES Revenue Analytics"},{name:"description",content:"Orçamentos e resultados por campanha."},{property:"og:title",content:"Campanhas — SOARES Revenue Analytics"},{property:"og:description",content:"Acompanhe investimento e aquisição por criativo."},{property:"og:type",content:"website"},{name:"twitter:card",content:"summary_large_image"}]}),component:CampaignsPage});

