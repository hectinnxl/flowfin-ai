import { defineNitroConfig } from "nitro/config";
import { fileURLToPath } from "node:url";

export default defineNitroConfig({
  noExternals: true,
  alias: { tslib: fileURLToPath(import.meta.resolve("tslib/tslib.es6.mjs")) },
});
