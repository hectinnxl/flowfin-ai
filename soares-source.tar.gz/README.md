# SOARES | Revenue Analytics

Cópia do projeto existente do Lovable, revisada e testada localmente.
Projeto de origem: https://lovable.dev/projects/ca71bbef-df4f-49b9-955d-a1ca3fcc3a1d
Commit exportado: 32818109e868f98c785b485e8d6ace492efef809

## Abrir nesta máquina

O painel fica em http://127.0.0.1:4173 enquanto o servidor está em execução.
Para iniciar novamente, execute INICIAR.ps1 na pasta do projeto.
A compilação está em .output e já contém o servidor e os arquivos públicos.

Em outra máquina com Node.js 22.16 ou superior:

    npm install
    npm run typecheck
    npm test
    npm run build
    npm start

O servidor de produção usa PORT (padrão 3000) e HOST. Nesta máquina, INICIAR.ps1 usa 127.0.0.1:4173.

## O que foi concluído

- As seis páginas e a identidade visual preto/dourado.
- Filtros de período aplicados aos leads, gastos, gráficos e ranking.
- Gastos por data e criativo refletidos em investimento, CPL e CAC.
- Demonstração separada, com aviso e exportação identificada.
- Busca, filtros de atendimento/consultor e retornos vencidos.
- CSV com cabeçalhos e proteção contra fórmulas em conteúdo textual.
- Login validado no servidor, sessão assinada e cookies HttpOnly.
- Integração server-side somente de leitura com a Google Sheets API.
- Mapeamento dos cabeçalhos reais da planilha, conferidos pelo conector.
- Layout e navegação conferidos em desktop e celular.

O saldo financeiro usa valor nominal contratado menos mídia. Não equivale a comissão, caixa ou lucro.
O gráfico diário agrupa contratos pela data de entrada do lead; a planilha não possui uma data de fechamento distinta.
Leads sem data de entrada válida ficam fora dos indicadores por período.
Ajustes manuais de mídia na interface são da sessão, não são gravados na planilha.

## Conectar os dados reais

A interface funciona com dados reais vazios e demonstração opcional.
Não há credenciais Google nem senha real do painel no código.

1. Configure uma conta de serviço no Google Cloud com Sheets API habilitada.
2. Conceda somente leitura da planilha à conta de serviço. Essa permissão deve ser configurada pelo proprietário.
3. Copie .env.example para .env e preencha GOOGLE_SERVICE_ACCOUNT_EMAIL e GOOGLE_PRIVATE_KEY.
4. Os intervalos já correspondem à planilha: 'Leads TikTok'!A:Q e 'Investimento Ads'!A4:E. Não mude a linha de cabeçalho de gastos.
5. Execute node scripts/create-password-hash.mjs e configure DASHBOARD_USER, DASHBOARD_PASSWORD_HASH e DASHBOARD_SESSION_SECRET.
6. Reinicie o servidor. Entre na tela de acesso administrativo e abra Configurações para sincronizar.

## Hospedagem Netlify e alteração de senha

O arquivo netlify.toml e o preset Netlify geram os arquivos públicos em dist e a função de servidor em .netlify/functions-internal. Não publique apenas dist por arrastar e soltar: o login precisa da função de servidor.

Publique este painel em um projeto Netlify separado do site institucional. Não substitua a publicação atual de soaressolucoes.net.br. Depois da validação, configure o subdomínio painel.soaressolucoes.net.br nesse novo projeto.

Configure DASHBOARD_USER, DASHBOARD_PASSWORD_HASH, DASHBOARD_SESSION_SECRET e NETLIFY=true nas variáveis acessíveis às Functions. Nunca use VITE_ para segredos.

O acesso permanece bloqueado quando o administrador não está configurado. Não há cadastro público. A opção Configurações > Alterar senha exige a senha atual, pelo menos 12 caracteres e confirmação. A senha nova é salva apenas como hash scrypt no armazenamento privado Netlify Blobs, com leitura consistente e escrita condicional. A troca invalida as sessões antigas e exige novo login. O armazenamento persiste entre publicações; contextos de preview e produção são separados.

Localmente, sem Netlify Blobs, a troca não é confirmada e retorna indisponibilidade em vez de alterar a senha apenas na memória. Os testes locais simulam esse armazenamento; a validação real ainda depende da publicação na Netlify.

As credenciais ficam apenas no ambiente do servidor. .env está ignorado pelo Git.
Em produção, use HTTPS e variáveis do provedor em vez de versionar um arquivo .env.
O acesso implementado é de um único usuário administrador. O limitador de tentativas é por processo; uma implantação com várias instâncias exige limitação compartilhada.
Não existe alteração de planilha, automação TikTok ou publicação de contatos nessa implementação.

Documentação usada:

- https://developers.google.com/identity/protocols/oauth2/service-account
- https://developers.google.com/workspace/sheets/api/scopes
- https://tanstack.com/start/latest/docs/framework/react/guide/server-functions

## Sincronizar com o Lovable

Esta cópia local ainda não foi enviada ao Lovable.
O conector GitHub não retornou repositórios acessíveis nesta sessão e o editor web do Lovable pediu login.
Para enviar as correções ao projeto original, conecte seu repositório GitHub e informe o link.
Não foi gasto crédito do agente Lovable para executar esta revisão.

## Verificação

Execute npm run typecheck, npm test e npm run build.
Os testes cobrem períodos, valores monetários, saneamento, ranking, CSV, autenticação, cookies, origem de requisições e leitura simulada da API Google.
A sincronização com a planilha real depende de configurar as credenciais descritas acima.
