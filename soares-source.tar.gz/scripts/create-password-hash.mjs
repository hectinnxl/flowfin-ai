import { randomBytes, scryptSync } from "node:crypto";
import { createInterface } from "node:readline/promises";
const rl = createInterface({ input: process.stdin, output: process.stdout });
const password = await rl.question("Senha para o painel (entrada visível; use em terminal privado): ");
rl.close();
if (password.length < 12) throw new Error("Use pelo menos 12 caracteres.");
const salt = randomBytes(16).toString("hex");
console.log("DASHBOARD_PASSWORD_HASH=scrypt:" + salt + ":" + scryptSync(password, salt, 64).toString("hex"));
console.log("DASHBOARD_SESSION_SECRET=" + randomBytes(48).toString("base64url"));
